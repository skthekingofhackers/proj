<?php

session_start();

// Check if the user is authenticated and has the required role
function authenticate($allowedRoles) {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
        header("Location: login.php");
        exit();
    }
}

// Retrieve user role
require_once 'db_connection.php'; // Assuming your db_connection.php file is in the same directory
$userRole = $_SESSION['user_role'];
$userId = $_SESSION['user_id'];

try {
    $query = "SELECT name FROM users WHERE id = :userId";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() === 1) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $_SESSION['name'] = $row['name'];
    }
} catch (PDOException $e) {
    // Handle the exception as needed
    echo "Error: " . $e->getMessage();
}
?>

