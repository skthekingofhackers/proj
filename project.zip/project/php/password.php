<?php
require_once("db_connection.php"); // Include your database connection script here
require_once("user_info.php");

// Check if the user is authenticated and allowed to change the password
authenticate(["admin", "operator"]);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $currentPassword = $_POST["currentPassword"];
    $newPassword = $_POST["newPassword"];
    $confirmPassword = $_POST["confirmPassword"];

    // Password validation regex
    $passwordPattern = '/^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!])(?!.*\s).{8,}$/';

    // Check if the new password matches the confirmation
    if ($newPassword !== $confirmPassword) {
        echo "Password and confirmation do not match.";
        exit;
    }

    // Check if the new password meets the validation criteria
    if (!preg_match($passwordPattern, $newPassword)) {
        $passwordError = "New password must be at least 8 characters long and contain at least one capital letter, one special character, and one digit.";
    } else {
        $passwordError = ""; // Reset the error message
    }

    // Get the logged-in user's user_id (you should replace this with your user identification logic)
    $userId = $_SESSION['user_id'];

    // Retrieve the user's hashed password and salt from the database
    $sql = "SELECT password, salt FROM users WHERE id = :userId";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

    if ($stmt->execute()) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $storedPasswordHash = $row['password'];
            $salt = $row['salt'];

            // Verify if the current password matches the stored password
            if (password_verify($currentPassword . $salt, $storedPasswordHash)) {
                // Hash the new password
                $hashedPassword = password_hash($newPassword . $salt, PASSWORD_DEFAULT);

                // Update the user's password in the database
                $updateSql = "UPDATE users SET password = :password WHERE id = :userId";
                $updateStmt = $pdo->prepare($updateSql);
                $updateStmt->bindParam(':userId', $userId, PDO::PARAM_INT);
                $updateStmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);

                if ($updateStmt->execute()) {
                    // Password changed successfully
                    echo "Password changed successfully!";

                    // Destroy the session and log the user out
                    session_destroy();

                    // Redirect to the login page or any other page as needed
                    header("Location: login.php");
                    exit();
                } else {
                    echo "Password change failed. Please try again later.";
                }
            } else {
                echo "Current password is incorrect.";
            }
        } else {
            echo "User not found.";
        }
    } else {
        echo "Error executing the query.";
    }
}
?>