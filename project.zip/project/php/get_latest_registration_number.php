<?php
require_once 'db_connection.php'; // Include the database connection file

try {
    // Fetch the latest registration number from the database
    $stmt = $pdo->prepare("SELECT MAX(registration_number) AS latest_registration_number FROM patients");
    $stmt->execute(); // Execute the prepared statement
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $latestRegistrationNumber = $result['latest_registration_number'];

    // Return the latest registration number as a response
    echo $latestRegistrationNumber ? $latestRegistrationNumber : 0;
} catch (PDOException $e) {
    http_response_code(500); // Set HTTP response code to indicate server error
    echo "Error: Connection failed.";
}
?>