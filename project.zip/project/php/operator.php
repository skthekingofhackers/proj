<?php
require_once('user_info.php');
authenticate('operator');
require_once 'navbar.php';

// Get last login time and date from session
$lastLoginDatetime = $_SESSION['last_login_datetime'] ?? "Unknown";

// Get current time of day
$currentHour = date('H');
$greeting = "";

if ($currentHour < 12) {
    $greeting = "Good morning";
} elseif ($currentHour < 18) {
    $greeting = "Good afternoon";
} else {
    $greeting = "Good evening";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INMAS</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-info bg-primary-subtle" style="font-family: 'Times New Roman', Times, serif;">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">INMAS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <span class="nav-link">Welcome, <?php echo $_SESSION['name']; ?></span>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link">Last Login: <?php echo $lastLoginDatetime; ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

<script src="../bootstrap/jquery-3.7.0.min.js"></script>
<script src="../bootstrap/js/popper.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../bootstrap/js/jquery.slim.min.js"></script>
<script>
    function updateDashboardStats() {
        $.ajax({
            url: 'fetch_dashboard_stats.php',
            dataType: 'json',
            success: function (data) {
                $('.dashboard-stat').eq(0).text(data.patientsRegisteredToday);
                $('.dashboard-stat').eq(1).text(data.receivedAmountToday);
            }
        });
    }

    // Fetch dashboard stats every 5 seconds
    setInterval(updateDashboardStats, 5000); // Adjust the interval as needed
</script>

</body>
</html>
