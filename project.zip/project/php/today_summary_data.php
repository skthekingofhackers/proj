<?php

require_once('db_connection.php');

try {

    $ctScanCountQuery = "SELECT COUNT(*) AS ctScanCount FROM patients WHERE sub_department = 'CT Scan' AND date = CURDATE()";
    $ctScanCountResult = $pdo->query($ctScanCountQuery);
    $ctScanCount = $ctScanCountResult->fetchColumn();


    $mriCountQuery = "SELECT COUNT(*) AS mriCount FROM patients WHERE sub_department = 'MRI' AND date = CURDATE()";
    $mriCountResult = $pdo->query($mriCountQuery);
    $mriCount = $mriCountResult->fetchColumn();


    $ultrasoundCountQuery = "SELECT COUNT(*) AS ultrasoundCount FROM patients WHERE sub_department = 'Ultrasound' AND date = CURDATE()";
    $ultrasoundCountResult = $pdo->query($ultrasoundCountQuery);
    $ultrasoundCount = $ultrasoundCountResult->fetchColumn();


    $totalRegistrationsQuery = "SELECT COUNT(*) AS totalRegistrations FROM patients WHERE date = CURDATE()";
    $totalRegistrationsResult = $pdo->query($totalRegistrationsQuery);
    $totalRegistrations = $totalRegistrationsResult->fetchColumn();


    $summaryData = array(
        'ctScanCount' => $ctScanCount,
        'mriCount' => $mriCount,
        'ultrasoundCount' => $ultrasoundCount,
        'totalRegistrations' => $totalRegistrations
    );

    header('Content-Type: application/json');
    echo json_encode($summaryData);
} catch (PDOException $e) {
    http_response_code(500); // Set HTTP response code to indicate server error
    echo "Error: Connection failed.";
}

$conn = null;
?>
