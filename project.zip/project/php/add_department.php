<?php
require_once('user_info.php'); // Include the user_info.php file
authenticate('admin');
require_once 'navbar.php';
// Get the user role from the session
include 'db_connection.php'; // Include your database connection

authenticate('admin');
$successMessage = $errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $departmentName = $_POST['departmentName'];

    // Insert department into the database
    $sql = "INSERT INTO departments (department_name) VALUES (:department_name)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':department_name', $departmentName);

    try {
        $stmt->execute();
        $successMessage = "Department added successfully.";
    } catch (PDOException $e) {
        $errorMessage = "Error adding department: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Department</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    
  </head>
<body>
<div class="container mt-5" style="font-family: 'Times New Roman', Times, serif;">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2 class="text-center">Add Department</h2>
                <?php if ($successMessage) : ?>
                    <div class="alert alert-success"><?php echo $successMessage; ?></div>
                <?php endif; ?>
                <?php if ($errorMessage) : ?>
                    <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                <?php endif; ?>
                <form action="" method="post">
                    <div class="mb-3">
                        <label for="departmentName" class="form-label">Department Name</label>
                        <input type="text" class="form-control" id="departmentName" name="departmentName" required>
                    </div>
                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary">Add Department</button>
                        <a href="previous_page.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="../bootstrap/jquery-3.7.0.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../bootstrap/js/popper.min.js"></script>
<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../javascript/update_departments.js"></script>
</body>
</html>
