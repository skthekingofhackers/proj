<?php
require_once 'user_info.php'; // Include the user_info.php file
authenticate(['admin', 'operator']);
require_once 'navbar.php';

// Include the database connection file
require_once('db_connection.php');

try {
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the user ID of the logged-in user
    $user_id = $_SESSION['user_id']; // Assuming you're storing user ID in the session

    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $contact = $_POST["contact"];
    $department = $_POST["department_name"];
    $sub_department = $_POST["sub_department"];
    $aadhar_no = $_POST["aadhar_no"];
    $registration_number = $_POST["registration_number"];
    $date = $_POST["date"]; // Use the existing date column
    $time = $_POST["time"];

    $rs_received = 10; // Fixed value of 10

    $stmt = $pdo->prepare("INSERT INTO patients (user_id, name, age, gender, contact, department, sub_department, aadhar_no, registration_number, date, time, rs_received) 
                                VALUES (:user_id, :name, :age, :gender, :contact, :department, :sub_department, :aadhar_no, :registration_number, :date, :time, :rs_received)");

    // Bind parameters to the prepared statement
    $stmt->bindParam(":user_id", $user_id);
    $stmt->bindParam(":name", $name);
    $stmt->bindParam(":age", $age);
    $stmt->bindParam(":gender", $gender);
    $stmt->bindParam(":contact", $contact);
    $stmt->bindParam(":department", $department);
    $stmt->bindParam(":sub_department", $sub_department);
    $stmt->bindParam(":aadhar_no", $aadhar_no);
    $stmt->bindParam(":registration_number", $registration_number);
    $stmt->bindParam(":date", $date);
    $stmt->bindParam(":time", $time);
    $stmt->bindParam(":rs_received", $rs_received);

    // Execute the prepared statement
    $stmt->execute();

    // Return the registration number as a response
    echo $registration_number;

    header("Location: download_card.php?registration_number=" . $registration_number);
    exit;
  }
} catch (PDOException $e) {
  http_response_code(500); // Set HTTP response code to indicate server error
  echo "Error: Connection failed.";
}

// Close the database connection

?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">

  <style>
    body{
      font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    }
    label {
      font-weight: bold;
      color: #333;
      margin-bottom: 5px;
      display: inline-block;
    }

    .is-invalid {
      border: 1px solid red;
    }

    /* Add this to your <style> tag or external CSS file */
    input:invalid {
      border: 1px solid red;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <form method="post" action="" id="registrationForm">

      <table align="center" class="table table-warning table-striped shadow-lg table-bordered mt-4">
        <tr>
          <td colspan="5" align="center">
            <h2 align='center' class=" display-5 text-uppercase">New Patient Registration</h2>
          </td>
        </tr>

        <tr>
          <td>Department:</td>
          <td>
            <select class="form-select" aria-label="Small select example" id="department" name="department_name" required>
              <option value="">Select Department</option>
              <?php
              include 'db_connection.php';
              $sql = "SELECT department_name FROM departments WHERE enabled = 1"; // Fetch only enabled departments

              try {
                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                  echo "<option value='" . $row['department_name'] . "'>" . $row['department_name'] . "</option>";
                }
              } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
              }
              ?>
            </select>
          </td>

          <td>Sub Department:</td>
          <td>
            <select class="form-select" aria-label="Small select example" id="sub_department_name" name="sub_department" required>
              <option value="">Select Sub Department</option>
            </select>
          </td>

        </tr>

        <tr>
          <td>Name:</td>
          <td><input type="text" class="form-control" name="name" pattern="[A-Za-z ]+" title="Name can only contain letters and spaces" required></td>

          <td>Age:</td>
          <td><input type="number" class="form-control" name="age" min="1" max="200" title="Age must be between 1 and 200" required></td>
        </tr>
        <tr>
          <td>Gender:</td>
          <td>
            <select class="form-select" aria-label="Small select example" id="gender" name="gender" required>
              <option value="">Select gender</option>
              <option value="Male" required>Male</option>
              <option value="Female" required>Female</option>
              <option value="other" required>Other</option>
            </select>
          <td>Contact No.:</td>
          <td><input type="tel" class="form-control" name="contact" pattern="[0-9]{10}" title="Mobile number should be 10 digits" required></td>
        </tr>

        <tr>
          <td>Aadhar No.:</td>
          <td><input type="text" class="form-control" name="aadhar_no" pattern="[0-9]{12}" title="Aadhar number should be 12 digits" required></td>
          <td>Registration Number:</td>
          <td><input type="number" id="registration_number" name="registration_number" class="form-control" value="1" readonly></td>
        </tr>
        <tr>
          <td>Date:</td>
          <td><input type="date" name="date" id="date" required></td>
          <td>Time:</td>
          <td><input type="time" name="time" id="time" required></td>
        </tr>
        <tr>
          <td colspan="5" align="center">
            <center><input type="submit" value="SUBMIT" class="btn btn-success btn-lg mt-2">
              <input type="reset" name="res" value="RESET" class="btn btn-primary btn-lg mt-2" onclick="resetFormFields()">
            </center>
          </td>
        </tr>
      </table>
    </form>


    <table align="center" class="table table-striped table-info table-bordered shadow-lg mt-4">
      <tr>
        <td colspan="5" align="center">
          <h2 align='center' class="display-6 text-uppercase">Today Summary</h2>
        </td>
      </tr>
      <tr>
        <td>CT Scan:</td>
        <td><span id="ctScanCount">0</span></td>
      </tr>
      <tr>
        <td>MRI:</td>
        <td><span id="mriCount">0</span></td>
      </tr>
      <tr>
        <td>Ultrasound:</td>
        <td><span id="ultrasoundCount">0</span></td>
      </tr>
      <tr>
        <td>Total Appointments of Today:</td>
        <td><span id="totalRegistrations">0</span></td>
      </tr>
    </table>
  </div>
  </div>
  <!-- Success Modal -->
  <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="successModalLabel">Success</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Registration successful!
        </div>
      </div>
    </div>
  </div>

  <!-- Failure Modal -->
  <div class="modal fade" id="failureModal" tabindex="-1" aria-labelledby="failureModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="failureModalLabel">Error</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Registration failed. Please try again.
        </div>
      </div>
    </div>
  </div>

  <script src="../bootstrap/jquery-3.7.0.min.js"></script>
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../bootstrap/js/popper.min.js"></script>
  <script src="../javascript/show_department.js"></script>
  <script src="../javascript/registration.js"></script>
  <script src="../javascript/validation.js"></script>
  <script src="../javascript/today_summary.js"></script>
</body>

</html>