<?php
require_once('user_info.php');
authenticate('admin');
require_once 'navbar.php';


$lastLoginDatetime = $_SESSION['last_login_datetime'] ?? "Unknown";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INMAS</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap-icons.css">
    <script src="../bootstrap/js/chart.js/dist/chart.umd.js"></script>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">INMAS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <span class="nav-link">Welcome, <?php echo $_SESSION['name']; ?></span>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link">Last Login: <?php echo $lastLoginDatetime; ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4" style="font-family: 'Times New Roman', Times, serif;">
        <div class="row">
            <div class="col">
                <label for="fromDate">From:</label>
                <input type="date" id="fromDate" class="form-control">
            </div>
            <div class="col">
                <label for="toDate">To:</label>
                <input type="date" id="toDate" class="form-control">
            </div>
            <div class="col mt-4">
                <button id="submitBtn" class="btn btn-primary">Generate Graph</button>
            </div>
        </div>
        <canvas id="chartCanvas" class="mt-4"></canvas>
    </div>

    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../bootstrap/js/flatpicker.min.js"></script>
    <script src="../javascript/graph.js"></script>
</body>

</html>
