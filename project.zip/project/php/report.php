<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Report</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Include Chart.js library -->
    <script src="../bootstrap/js/chart.js/dist/chart.umd.js"></script>
    <script src="../bootstrap/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
    <style>
        .graph-container {
            margin: 20px;
        }

        .report-container {
            margin: 20px;
        }

        .chart-container {
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
        }

        .chart-box {
            flex: 1;
            margin: 10px;
            text-align: center;
        }

    </style>
</head>

<body>
    <div class="report-container" style="font-family: 'Times New Roman', Times, serif;">
        <h2 class="display-4 text-center mt-4">User Report</h2>

        <?php
        require_once 'db_connection.php'; // Include the database connection script

        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user_id'])) {
            $user_id = $_POST['user_id'];

            // Fetch user details
            $user_query = "SELECT * FROM users WHERE id = :user_id";
            $user_stmt = $pdo->prepare($user_query);
            $user_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $user_stmt->execute();
            $user = $user_stmt->fetch(PDO::FETCH_ASSOC);

            // Fetch patient data for the user
            $patient_query = "SELECT sub_department, COUNT(*) AS count, SUM(rs_received) AS total_rs
                         FROM patients
                         WHERE user_id = :user_id
                         GROUP BY sub_department";
            $patient_stmt = $pdo->prepare($patient_query);
            $patient_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $patient_stmt->execute();
            $patient_data = $patient_stmt->fetchAll(PDO::FETCH_ASSOC);

            // Prepare data for the graphs
            $sub_departments = [];
            $patient_counts = [];
            $rs_collected = [];
            foreach ($patient_data as $row) {
                $sub_departments[] = $row['sub_department'];
                $patient_counts[] = $row['count'];
                $rs_collected[] = $row['total_rs'];
            }

            // Display user details
            echo '<h3 class="text-dark">User Details</h3>';
            echo '<p class="text-dark">User ID: ' . $user['id'] . '</p>';
            echo '<p class="text-dark">Name: ' . $user['name'] . '</p>';

            // Display charts and add text labels
            echo '<div class="chart-container">';

            // Patient Count Chart
            echo '<div class="chart-box" style="width: 40%; text-align: center;">';
            echo '<canvas id="patientCountChart"></canvas>';
            echo '<p>This is Patient Count Chart</p>';
            echo '</div>';

            // Rs Collected Chart
            echo '<div class="chart-box" style="width: 40%; text-align: center;">';
            echo '<canvas id="rsCollectedChart"></canvas>';
            echo '<p>This is Rs Collected Chart</p>';
            echo '</div>';

            echo '</div>'; // Close the chart container

            // Table for Patient Counts
            echo '<div class="table-responsive mt-4">
            <h4 class="text-dark">Patient Counts Table</h4>
            <table class="table table-bordered table-striped table-ligh shadow-sm">
                <thead align="center"> 
                    <tr>
                        <th>Sub Department</th>
                        <th>Number of Patients</th>
                    </tr>
                </thead>
                <tbody align="center">';
            foreach ($patient_data as $row) {
                echo '<tr>
                    <td>' . $row['sub_department'] . '</td>
                    <td>' . $row['count'] . '</td>
                </tr>';
            }
            echo '</tbody></table></div>';

            // Table for Rs Collected
            echo '<div class="table-responsive mt-4">
            <h4 class="text-dark">Rs Collected Table</h4>
            <table class="table table-bordered table-striped table-light shadow-sm">
                <thead align="center">
                    <tr>
                        <th>Sub Department</th>
                        <th>Total Rs Collected</th>
                    </tr>
                </thead>
                <tbody align="center">';
            foreach ($patient_data as $row) {
                echo '<tr>
                    <td>' . $row['sub_department'] . '</td>
                    <td>' . $row['total_rs'] . '</td>
                </tr>';
            }
            echo '</tbody></table></div>';

            // JavaScript for generating graphs
            echo '<script>
            var patientCountChart = new Chart(document.getElementById("patientCountChart"), {
                type: "bar",
                data: {
                    labels: ' . json_encode($sub_departments) . ',
                    datasets: [{
                        label: "Number of Patients",
                        data: ' . json_encode($patient_counts) . ',
                        backgroundColor: [
                            "rgba(65, 105, 225, 0.8)",
                            "rgba(30, 144, 255, 0.8)",
                            "rgba(0, 0, 139, 0.8)"
                        ],
                        borderColor: [
                            "rgba(65, 105, 225, 1)",
                            "rgba(30, 144, 255, 1)",
                            "rgba(0, 0, 139, 1)"
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });

            var rsCollectedChart = new Chart(document.getElementById("rsCollectedChart"), {
                type: "bar",
                data: {
                    labels: ' . json_encode($sub_departments) . ',
                    datasets: [{
                        label: "Rs Collected",
                        data: ' . json_encode($rs_collected) . ',
                        backgroundColor: [
                            "rgba(65, 105, 225, 0.8)",
                            "rgba(30, 144, 255, 0.8)",
                            "rgba(0, 0, 139, 0.8)"
                        ],
                        borderColor: [
                            "rgba(65, 105, 225, 1)",
                            "rgba(30, 144, 255, 1)",
                            "rgba(0, 0, 139, 1)"
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        </script>';
        } else {
            echo '<p class="text-dark">No user selected for generating the report.</p>';
        }
        ?>

    </div>
    <div class="text-center mt-4 mb-5">
        <button id="downloadReportBtn" class="btn btn-outline-success">Download Report</button>
        <a href="my_summary.php" class="btn btn-outline-info">Back</a>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../bootstrap/jspdf.umd.min.js"></script>
    <script>
        document.getElementById("downloadReportBtn").addEventListener("click", function() {
            // Capture a screenshot of the report container
            html2canvas(document.querySelector(".report-container")).then(function(canvas) {
                // Create a new jsPDF instance
                const pdf = new window.jspdf.jsPDF();
                const imgData = canvas.toDataURL("image/png");

                // Set the report title
                const reportTitle = "User Report";

                // Get the user details
                const userName = "<?php echo $user['name']; ?>";
                const userId = "<?php echo $user['id']; ?>";

                // Modify the filename to include user's name and ID
                const fileName = "<?php echo $user['name'] . '_' . $user['id'] . '_report.pdf'; ?>";

                // Add the title to the PDF
                // Adjust the image size (width and height) in the PDF
                const pdfWidth = 190; // Adjust this value
                const pdfHeight = 190;

                // Center the image horizontally
                const marginLeft = (pdf.internal.pageSize.width - pdfWidth) / 2;

                // Calculate the vertical position for the image
                const marginTop = 20; // Adjust this value

                // Add the image with border
                pdf.rect(marginLeft - 5, marginTop - 5, pdfWidth + 10, pdfHeight + 10, "S"); // Add border
                pdf.addImage(imgData, "PNG", marginLeft, marginTop, pdfWidth, pdfHeight);

                // Save the PDF with the modified filename
                pdf.save(fileName);
            });
        });
    </script>
</body>

</html>