<?php
require_once('db_connection.php'); // Include the database connection file

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fromDate = $_POST["from_date"];
        $toDate = $_POST["to_date"];

        $stmt = $pdo->prepare("SELECT department, sub_department,
            SUM(CASE WHEN sub_department = 'CT Scan' THEN 1 ELSE 0 END) AS ct_scan_total,
            SUM(CASE WHEN sub_department = 'MRI' THEN 1 ELSE 0 END) AS mri_total,
            SUM(CASE WHEN sub_department = 'Ultrasound' THEN 1 ELSE 0 END) AS ultrasound_total
            FROM patients
            WHERE date BETWEEN :fromDate AND :toDate
            GROUP BY department, sub_department");

        $stmt->bindParam(":fromDate", $fromDate);
        $stmt->bindParam(":toDate", $toDate);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: application/json');
        echo json_encode($result);
    }
} catch (PDOException $e) {
    http_response_code(500); // Set HTTP response code to indicate server error
    echo "Error: Connection failed.";
}
// No need to close the connection here
?>
