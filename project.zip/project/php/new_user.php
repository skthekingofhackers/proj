<?php
require_once 'user_info.php';
require_once 'db_connection.php'; // Include your database connection code using PDO
require_once 'navbar.php';
// Check if the user is authenticated and has the 'admin' role
authenticate('admin');

$errorMessage = "";
$successMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user inputs from the form
    $role = $_POST['role'];
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    // Validate password confirmation
    if ($password !== $confirmPassword) {
        $errorMessage = "Passwords do not match.";
    } else {
        // Validate username (alphanumeric)
        if (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
            $errorMessage = "Username must be alphanumeric.";
        }
        // Validate password (alphanumeric, capital letter, special character)
        elseif (!preg_match('/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password)) {
            $errorMessage = "Password must be at least 8 characters long, contain an uppercase letter, a digit, and a special character.";
        } else {
            try {
                // Check if the username already exists in the database
                $query = "SELECT COUNT(*) as count FROM users WHERE username = ?";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$username]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($result['count'] > 0) {
                    $errorMessage = "Username already exists.";
                } else {
                    // Generate a random salt
                    $salt = bin2hex(random_bytes(16));

                    // Combine the password and salt, then hash them
                    $hashedPassword = password_hash($password . $salt, PASSWORD_DEFAULT);

                    // Insert new user into the database using PDO
                    $query = "INSERT INTO users (role, name, username, password, salt) VALUES (?, ?, ?, ?, ?)";
                    $stmt = $pdo->prepare($query);
                    $stmt->execute([$role, $name, $username, $hashedPassword, $salt]);

                    // User created successfully
                    $successMessage = "User created successfully with the username: " . $username;
                }
            } catch (PDOException $e) {
                // Handle database error
                $errorMessage = "Error creating user: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New User</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/new_user.css">
</head>

<body>

    <div id="successMessageContainer" class="alert alert-success alert-dismissible" style="display: <?php echo $successMessage ? 'block' : 'none'; ?>;">
        <?php echo $successMessage; ?>
    </div>
    <div class="center" style="font-family: 'Times New Roman', Times, serif;">
        <div class="card">
            <div class="card-header">
                <h2 class="mb-0" align="center"><b>Create New User</b></h2>
            </div>
            <div class="card-body">
                <form action="" id="registrationForm" method="post">
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <div class="select-arrow">
                            <select class="form-control" id="role" name="role" required>
                                <option value="" disabled selected>Select Role</option>
                                <option value="operator">Operator</option>
                                <option value="admin">Admin</option>
                                <option value="pathologist">Pathologist</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" pattern="[a-zA-Z0-9]+" required>

                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" pattern="^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" required>

                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                            required>
                        <small id="passwordMatchError" class="form-text text-danger"
                            style="display: none;">Passwords do not match.</small>
                    </div>
                    <button type="submit" class="btn btn-outline-primary"onclick="return validateForm();"><b>Create User</b></button>
                    <button type="reset" class="btn btn-outline-danger" onclick="resetSuccessMessage();"><b>Reset</b></button>
                </form>
            </div>
        </div>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script>
        function resetSuccessMessage() {
            var successMessageContainer = document.getElementById("successMessageContainer");
            successMessageContainer.style.display = "none";
            successMessageContainer.innerHTML = ""; // Clear the content
        }
        function validateForm() {
            var passwordInput = document.getElementById("password");
            var confirmInput = document.getElementById("confirm_password");
            var passwordMatchError = document.getElementById("passwordMatchError");

            if (passwordInput.value !== confirmInput.value) {
                passwordMatchError.style.display = "block";
                return false; // Prevent form submission
            } else {
                passwordMatchError.style.display = "none";
                return true; // Allow form submission
            }
        }
    </script>

</body>

</html>