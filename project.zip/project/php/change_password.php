<?php

require_once("user_info.php");
authenticate(["admin","operator"]);
require_once 'navbar.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .containerhere {
            max-width: 400px;
            margin: 100px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            animation: fadein 1s ease-in-out forwards;
            opacity: 0;
            visibility: hidden;
        }

        .success-message,
        .error-message {
            display: none;
            margin-top: 10px;
        }

        .success i,
        .error i {
            margin-right: 5px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
        @keyframes fadein {
            to {
                opacity: 1;
                visibility: visible;
            }
        }
    </style>
</head>
<body>
<div class="containerhere" style="font-family: 'Times New Roman', Times, serif;">
        <h2> Change Password</h2>
        <form id="changePasswordForm" method="post" action="password.php"> <!-- Added 'method' and 'action' attributes -->
            <div class="form-group mt-2">
                <label for="currentPassword">Current Password:</label>
                <input type="password" class="form-control" id="currentPassword" name="currentPassword" required>
            </div>
            <div class="form-group mt-2">
                <label for="newPassword">New Password:</label>
                <input type="password" class="form-control" id="newPassword" name="newPassword" required>
                <span id="passwordErrorMessage" style="font-size: 12px;"></span> <!-- Display password error message here -->
            </div>
            <div class="form-group mt-2">
                <label for="confirmPassword">Confirm Password:</label>
                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
            </div>
            <button type="submit" class="btn btn-primary mt-3 mb-2">
                 Submit
            </button>
            <button type="button" class="btn btn-secondary btn-back mt-3 mb-2">
                 Back
            </button>
        </form>

    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const newPasswordInput = document.getElementById("newPassword");
            const passwordErrorMessage = document.getElementById("passwordErrorMessage");

            newPasswordInput.addEventListener("input", function () {
                const newPassword = newPasswordInput.value;
                const passwordPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!])(?!.*\s).{8,}$/;

                if (!newPassword.match(passwordPattern)) {
                    passwordErrorMessage.style.color = "red";
                    passwordErrorMessage.textContent = "New password must be at least 8 characters long and contain at least one capital letter, one special character, and one digit.";
                } else {
                    passwordErrorMessage.style.color = "green"; // You can change the color to any desired style
                    passwordErrorMessage.textContent = "Password meets the criteria.";
                }
            });
        });
    </script>
</body>
</html>