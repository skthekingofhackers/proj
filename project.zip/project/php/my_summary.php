<?php
require_once('user_info.php'); // Include the user_info.php file
authenticate('admin');
require_once 'navbar.php';
require_once 'db_connection.php'; // Include the database connection script
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Report</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>

<body>
    <div class="container-fluid" style="font-family: 'Times New Roman', Times, serif;">
        <h2 class="display-4 text-center mt-4">Registration Report</h2>
        <form method="post" class="mt-4">
            <div class="row justify-content-center">
                <div class="col-md-3">
                    <label for="fromDate">From Date:</label>
                    <input type="date" name="fromDate" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label for="toDate">To Date:</label>
                    <input type="date" name="toDate" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary mt-4">Generate Report</button>
                </div>
            </div>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $fromDate = $_POST['fromDate'];
            $toDate = $_POST['toDate'];

            // Retrieve user ID from the session
            $loggedInUserId = $_SESSION['user_id'];

            // Fetch registration details for the selected date range and the logged-in user
            $query = "SELECT u.id AS user_id, u.name AS user_name,
    u.name AS name,
    COALESCE(SUM(CASE WHEN p.sub_department = 'CT Scan' THEN 1 ELSE 0 END), 0) AS ct_count,
    COALESCE(SUM(CASE WHEN p.sub_department = 'MRI' THEN 1 ELSE 0 END), 0) AS mri_count,
    COALESCE(SUM(CASE WHEN p.sub_department = 'Ultrasound' THEN 1 ELSE 0 END), 0) AS ultrasound_count,
    COALESCE(SUM(CASE WHEN p.sub_department IN ('CT Scan', 'MRI', 'Ultrasound') THEN 1 ELSE 0 END), 0) AS total_count
    FROM users u
    LEFT JOIN patients p ON u.id = p.user_id AND p.date BETWEEN :fromDate AND :toDate
    WHERE u.id = :loggedInUserId
    GROUP BY u.id, u.name";

            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':fromDate', $fromDate, PDO::PARAM_STR);
            $stmt->bindParam(':toDate', $toDate, PDO::PARAM_STR);
            $stmt->bindParam(':loggedInUserId', $loggedInUserId, PDO::PARAM_INT);
            $stmt->execute();
            $registrationData = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($registrationData) > 0) {
                echo '<table class="table table-bordered mt-4 table-hover table-responsive table-info">
                    <thead align="center">
                        <tr>
                        <th>Name</th>
                            <th>User ID</th>
                            <th>CT Scan</th>
                            <th>MRI</th>
                            <th>Ultrasound</th>
                            <th>Total</th>
                            <th>Rs Received</th>
                            <th>Generate report</th>
                        </tr>
                    </thead>
                    <tbody align="center">';
                foreach ($registrationData as $row) {
                    $rsReceived = $row['total_count'] * 10; // Rs received per registration is 10
                    echo '<tr>
                    <td>' . $row['name'] . '</td>
                    <td>' . $row['user_id'] . '</td>
                    <td>' . $row['ct_count'] . '</td>
                    <td>' . $row['mri_count'] . '</td>
                    <td>' . $row['ultrasound_count'] . '</td>
                    <td>' . $row['total_count'] . '</td>
                    <td>' . $rsReceived . '</td>
                    <td>
                    <form method="post" action="report.php">
                        <input type="hidden" name="user_id" value="' . $row['user_id'] . '">
                        <button type="submit" class="btn btn-primary btn-sm">Generate Report</button>
                    </form>
                </td>
                </tr>';
                }
                echo '</tbody></table>';
            } else {
                echo '<p class="mt-4">No registration data found for the selected date range.</p>';
            }
        }
        ?>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>