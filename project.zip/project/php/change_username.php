<?php
require_once('user_info.php');
authenticate('admin');
require_once 'navbar.php';
// Include your database connection initialization
require_once('db_connection.php');

$currentUsername = '';

// Check if the user is logged in and retrieve the current username from the session
if (isset($_SESSION['user_id'])) {
    $userID = $_SESSION['user_id'];

    // Retrieve the current username from the database
    $query = "SELECT username FROM users WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$userID]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $currentUsername = $user['username'];
    }
}

$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = $_POST['new_username'];

    try {
        // Check if the new username is available
        $query = "SELECT COUNT(*) as count FROM users WHERE username = ? AND id != ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$newUsername, $userID]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result['count'] === 0) {
            // Update the username in the database
            $query = "UPDATE users SET username = ? WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$newUsername, $userID]);
    
            // Update the current username for display
            $currentUsername = $newUsername;
    
            $successMessage = "Username changed successfully.";
        } else {
            $errorMessage = "Username is already taken.";
        }
    } catch (PDOException $e) {
        $errorMessage = "Error changing username: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Change username</title>
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Include your head elements here -->
    

    <style>
        /* Add custom styles here */
        .content-box {
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .content-box:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        /* Custom styles for changing navigation bar item text color */
        .navbar-nav .nav-link {
            color: black; /* Change the color to black */
        }

    </style>
</head>
<body>
    <!-- Your navigation bar content -->
  <div class="container mt-5" style="font-family: 'Times New Roman', Times, serif;">
        <div class="row justify-content-center">
            <div class="col-md-6 content-box">
                <?php if (!empty($successMessage)) : ?>
                    <div class="alert alert-success"><?php echo $successMessage; ?></div>
                <?php endif; ?>
                <?php if (!empty($errorMessage)) : ?>
                    <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                <?php endif; ?>

                <h2>Change Username</h2>
                <form action="" method="post">
                    <div class="form-group mt-2">
                        <label for="current_username">Current Username:</label>
                        <input type="text" class="form-control" id="current_username" value="<?php echo htmlspecialchars($currentUsername); ?>" disabled>
                    </div>
                    <div class="form-group mt-2">
                        <label for="new_username">New Username:</label>
                        <input type="text" class="form-control" name="new_username" id="new_username" required>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3 mb-2">Update</button>
                    <a href="#" class="btn btn-danger mt-3 mb-2">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
