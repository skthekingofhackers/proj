<?php
require_once 'user_info.php';
require_once('db_connection.php');
authenticate(['admin', 'operator']);
require_once 'navbar.php';

// Initialize search variables
$searchField = "";
$searchValue = "";
$fromDate = "";
$toDate = "";

// Handle the search query
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchField = $_POST["searchField"];
    $searchValue = $_POST["searchValue"];
    $fromDate = $_POST["fromDate"];
    $toDate = $_POST["toDate"];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Records</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
</head>
<body>
    <div class="container mt-3 justify-content-center" style="font-family: 'Times New Roman', Times, serif;">
        <h2 align="center">Duplicate Card</h2>
        <div class="d-flex justify-content-center col-12">
            <form method="POST" class="d-flex collapse align-items-center">
                <label for="searchField" class="col-1">Search by:</label>
                <select name="searchField" id="searchField" class="form-select shadow-sm ms-2">
                    <option value="">Select option</option>
                    <option value="registration_number">Registration Number</option>
                    <option value="name">Name</option>
                    <option value="contact">Contact</option>
                </select>

                <input type="text" name="searchValue" class="form-control shadow-sm ms-2" placeholder="Search Value">

                <label for="fromDate" class="col-1 ms-2">From Date:</label>
                <input type="date" name="fromDate" class="form-control shadow-sm ms-2" id="fromDate">

                <label for="toDate" class="col-1 ms-2">To Date:</label>
                <input type="date" name="toDate" class="form-control shadow-sm ms-2" id="toDate">

                <button type="submit" class="btn btn-primary ms-2">Search</button>
            </form>
        </div>
        <div class="justify-content-center mt-4 d-flex">
            <table class="table table-primary table-bordered table-striped table-hover shadow-lg">
                <thead align="center" class="text-uppercase">
                    <tr>
                        <th>Registration Number</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Age</th>
                        <th>Department</th>
                        <th>Sub department</th>
                        <th>Date of Registration</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody align="center">
                    <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        try {
                            // Connect to your database using PDO (replace with your database credentials)
                            $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
                            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                            // Construct the SQL query based on search conditions
                            $sql = "SELECT * FROM patients WHERE 1";

                            if (!empty($searchField) && !empty($searchValue)) {
                                $sql .= " AND $searchField LIKE :searchValue";
                                $searchValue = "%$searchValue%";
                            }

                            if (!empty($fromDate) && !empty($toDate)) {
                                $sql .= " AND date BETWEEN :fromDate AND :toDate";
                            }

                            $stmt = $pdo->prepare($sql);

                            if (!empty($searchValue) && $searchField !== "date") {
                                $stmt->bindParam(":searchValue", $searchValue);
                            }

                            if (!empty($fromDate) && !empty($toDate)) {
                                $stmt->bindParam(":fromDate", $fromDate);
                                $stmt->bindParam(":toDate", $toDate);
                            }

                            $stmt->execute();

                            if ($stmt->rowCount() > 0) {
                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    echo "<tr>";
                                    echo "<td>" . $row["registration_number"] . "</td>";
                                    echo "<td>" . $row["name"] . "</td>";
                                    echo "<td>" . $row["contact"] . "</td>";
                                    echo "<td>" . $row["age"] . "</td>";
                                    echo "<td>" . $row["department"] . "</td>";
                                    echo "<td>" . $row["sub_department"] . "</td>";
                                    echo "<td>" . $row["date"] . "</td>";
                                    echo "<td><a href='download_card.php?registration_number={$row['registration_number']}' class='btn btn-primary btn-sm'>View/download</a>
                                    </td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='8'>No matching records found.</td></tr>";
                            }
                        } catch (PDOException $e) {
                            die("Database connection failed: " . $e->getMessage());
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
