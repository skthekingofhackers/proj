<?php
require_once('db_connection.php');

if (isset($_GET['department'])) {
    $selectedDepartment = $_GET['department'];
    // Assuming you have a table structure similar to 'departments' and 'sub_departments'
    $sql = "SELECT sub_department_name FROM sub_departments WHERE department_name = :department";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':department', $selectedDepartment);
    $stmt->execute();
    $subDepartments = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    header('Content-Type: application/json');
    echo json_encode($subDepartments);
} else {
    echo "Department parameter not provided.";
}
?>
