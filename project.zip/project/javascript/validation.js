// validation.js
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("registrationForm");
  
    form.addEventListener("input", function (event) {
      const input = event.target;
      const validity = input.validity;
  
      if (!validity.valid) {
        input.classList.add("is-invalid");
      } else {
        input.classList.remove("is-invalid");
      }
    });
  });
  