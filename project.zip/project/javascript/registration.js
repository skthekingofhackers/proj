
// Function to set current live time and today's date
function setCurrentDateTime() {
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');

    // Update the date and time fields every second
    setInterval(() => {
        const now = new Date();
        const currentDate = formatDate(now); // Get the current date in the format "YYYY-MM-DD"
        const currentTime = getCurrentTime(now);

        dateInput.value = currentDate;
        timeInput.value = currentTime;
    }, 1000); // Update every 1000 milliseconds (1 second)
}

// Function to format the date in "YYYY-MM-DD" format
function formatDate(date) {
    const year = date.getFullYear().toString();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Function to get the current live time in "hh:mm" format
function getCurrentTime(now) {
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}
function showSuccessModal() {
    $('#successModal').modal('show');
  }

  function showFailureModal() {
    $('#failureModal').modal('show');
  }


  $('#registrationForm').submit(function(event) {
    event.preventDefault();

    $.ajax({
        url: $(this).attr('action'),
        method: 'POST',
        data: $(this).serialize(),
        success: function(response) {
            if (response.startsWith("Error:")) {
                // Registration failed
                showFailureModal();
            } else {
                // Registration successful
                showSuccessModal();
            }
        },
        error: function() {
            // Registration failed
            showFailureModal();
        }
    });
});
// Function to close the success modal after 3 seconds
function closeSuccessModal() {
    setTimeout(function () {
      $('#successModal').modal('hide');
      location.reload(); // Reload the page
    }, 3000); // 3000 milliseconds = 3 seconds
  }
  
  // Function to close the failure modal after 3 seconds
  function closeFailureModal() {
    setTimeout(function () {
      $('#failureModal').modal('hide');
      location.reload(); // Reload the page
    }, 3000); // 3000 milliseconds = 3 seconds
  }



function updateRegistrationNumber() {
    $.ajax({
        type: "GET",
        url: "../php/get_latest_registration_number.php", // Change the URL accordingly
        success: function (data) {
            const latestRegistrationNumber = parseInt(data);

            if (!isNaN(latestRegistrationNumber)) {
                const incrementedNumber = latestRegistrationNumber + 1;
                document.getElementById('registration_number').value = incrementedNumber;
            } else {
                console.log("Invalid registration number:", data); // Debug: Log the invalid data
                showFailureModal();
            }
        },
        error: function (xhr, status, error) {
            console.log("Error fetching registration number: " + error);
            showFailureModal();
        }
    });
}

$('#registrationForm').submit(function(event) {
    event.preventDefault();

    $.ajax({
        url: $(this).attr('action'),
        method: 'POST',
        data: $(this).serialize(),
        success: function(response) {
            if (response.startsWith("Error:")) {
                // Registration failed
                showFailureModal();
            } else {
                // Registration successful
                showSuccessModal();
                // Update the registration number after successful submission
                updateRegistrationNumber();
            }
        },
        error: function() {
            // Registration failed
            showFailureModal();
        }
    });
});

// Function to reset form fields (except appointment number, date, and time)
function resetFormFields() {
    const form = document.getElementById('registrationForm');
    const registrationNumberInput = document.getElementById('registration_number');
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');

    const currentRegistrationNumber = registrationNumberInput.value;
    const currentDate = dateInput.value;
    const currentTime = timeInput.value;

    form.reset();

    // Restore the initial values of appointment number, date, and time fields
    registrationNumberInput.value = currentRegistrationNumber;
    dateInput.value = currentDate;
    timeInput.value = currentTime;

    // Hide the success message after resetting the form
    hideSuccessMessage();
}


// Attach event listeners to form fields
document.addEventListener('DOMContentLoaded', function () {
   
 // Set current live time and today's date on page load
    setCurrentDateTime();


    // Event listener for form reset
    const resetButton = document.querySelector('input[type="reset"]');
    resetButton.addEventListener('click', function (event) {
        event.preventDefault(); // Prevent default form reset behavior
        resetFormFields();
    });
  // Event listeners for success and failure modals
  // Event listeners for success and failure modals
  $('#successModal').on('shown.bs.modal', function () {
    closeSuccessModal(); // Attach the closeSuccessModal function to the success modal when it's shown
  });

  $('#failureModal').on('shown.bs.modal', function () {
    closeFailureModal(); // Attach the closeFailureModal function to the failure modal when it's shown
  });

    // Call the function to fetch and update the appointment number on page load
    updateRegistrationNumber();

});

