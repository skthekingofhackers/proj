-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 20, 2023 at 12:13 PM
-- Server version: 10.11.4-MariaDB-1
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imaging_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `department_name` varchar(255) NOT NULL,
  `enabled` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_name`, `enabled`) VALUES
(1, 'Imaging', 1),
(3, 'lan', 1);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `registration_number` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `department` varchar(50) NOT NULL,
  `sub_department` varchar(50) NOT NULL,
  `aadhar_no` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`registration_number`, `name`, `age`, `gender`, `contact`, `department`, `sub_department`, `aadhar_no`, `date`, `time`) VALUES
(1, 'sunil kumar', 22, 'Male', '9654083988', 'imaging', 'CT scan', '498192301364', '2023-08-07', '21:03:00'),
(2, 'sunny', 22, 'Male', '9654083988', 'imaging', 'Ultrasound', '498192301363', '2023-08-07', '21:03:00'),
(3, 'sunny kumar', 22, 'Male', '9053647890', 'imaging', 'MRI', '498192301364', '2023-08-07', '21:03:00'),
(4, 'dqsnjk', 20, 'Male', '9654083988', 'imaging', 'Ultrasound', '498192300002', '2023-08-07', '21:41:00'),
(5, 'fsnaks', 20, 'Male', '9678583988', 'imaging', 'MRI', '498192300003', '2023-08-07', '21:49:00'),
(6, 'sunil', 23, 'Male', '9654083988', 'imaging', 'Ultrasound', '345766780876', '2023-08-07', '22:04:00'),
(7, 'sunil', 23, 'Male', '9654083988', 'imaging', 'Ultrasound', '345766780876', '2023-08-07', '22:06:00'),
(8, 'sunil kumar', 77, 'Male', '8847438292', 'imaging', 'CT scan', '293849494949', '2023-08-07', '22:14:00'),
(9, 'askdfna', 36, 'Male', '8976566547', 'imaging', 'Ultrasound', '467567490234', '2023-08-07', '22:21:00'),
(10, 'sdhaf', 20, 'Male', '9654083988', 'imaging', 'CT scan', '487534747474', '2023-08-11', '02:47:00'),
(13, 'faksjdf', 39, 'Male', '8864589657', 'imaging', 'Ultrasound', '876575758686', '2023-08-11', '03:03:00'),
(14, 'sunil kumar', 39, 'Male', '9053647890', 'imaging', 'CT scan', '474747474747', '2023-08-11', '03:26:00'),
(15, 'xca', 33, 'Male', '9053647890', 'imaging', 'CT scan', '498192301334', '2023-08-11', '03:28:00'),
(16, 'xca', 33, 'Male', '9053647890', 'imaging', 'CT scan', '498192301334', '2023-08-11', '03:28:00'),
(17, 'xca', 33, 'Male', '9053647890', 'imaging', 'CT scan', '498192301334', '2023-08-11', '03:33:00'),
(18, 'xca', 33, 'Male', '9053647890', 'imaging', 'CT scan', '498192301334', '2023-08-11', '03:35:00'),
(19, 'sunil kumar', 20, 'Male', '9654083988', 'imaging', 'Ultrasound', '498192301362', '2023-08-12', '18:56:00');

-- --------------------------------------------------------

--
-- Table structure for table `sub_departments`
--

CREATE TABLE `sub_departments` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `sub_department_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_departments`
--

INSERT INTO `sub_departments` (`id`, `department_id`, `sub_department_name`) VALUES
(1, 1, 'CT Scan'),
(2, 1, 'Ultrasound'),
(3, 1, 'MRI'),
(7, 3, 'Programming');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `name`, `username`, `password`, `salt`, `enabled`) VALUES
(1, 'admin', 'sunil', 'admin', '$2y$10$auPJ5E8KTHq1ePqi8qP7kOQLddbnZdMefkjYUbRgmF/LXdLGHDIzy', '60e7d97e6123a82abdf55803efb60a38', 1),
(2, 'operator', 'ajay', 'ajay', '$2y$10$VBqVLBs2LpEXHmAQ7J1aQerQqirajQiLFRS6h4QlMjWVcBjYd3T66', '2dd3844cdc704c9de5d7774d89cfd705', 1),
(13, 'operator', 'sunil', 'sunil', '$2y$10$t.QaBOtEKuxMEU.cuM07.eDFhfycmS2qNTLgDBx15kZtbLtlbNRge', '9ecfc10c768e24bb88daaa1d4791eb23', 1),
(14, 'pathologist', 'path', 'path', '$2y$10$yyLS6U.0MYAVPC/1rnlzCOIg4mdz43Un2uwRKdZeQssTFQAMh3O4q', 'bf1885792cfdcd0fb7dfa250768329b7', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`registration_number`);

--
-- Indexes for table `sub_departments`
--
ALTER TABLE `sub_departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sub_departments`
--
ALTER TABLE `sub_departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sub_departments`
--
ALTER TABLE `sub_departments`
  ADD CONSTRAINT `sub_departments_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
