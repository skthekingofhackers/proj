-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 27, 2023 at 09:34 PM
-- Server version: 10.11.4-MariaDB-1
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imaging_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `department_name` varchar(255) NOT NULL,
  `enabled` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_name`, `enabled`) VALUES
(1, 'imaging', 1),
(3, 'lan', 1);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `registration_number` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `department` varchar(50) NOT NULL,
  `sub_department` varchar(50) NOT NULL,
  `aadhar_no` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `user_id` int(11) NOT NULL,
  `rs_received` decimal(10,2) DEFAULT 10.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`registration_number`, `name`, `age`, `gender`, `contact`, `department`, `sub_department`, `aadhar_no`, `date`, `time`, `user_id`, `rs_received`) VALUES
(1, 'sunil2', 22, 'Male', '9654083988', 'imaging', 'CT Scan', '498192301369', '2023-08-25', '00:45:00', 2, 10.00),
(2, 'sunil', 25, 'Male', '8787899987', 'imaging', 'CT Scan', '498192301362', '2023-08-25', '16:52:00', 2, 10.00),
(3, 'sunny', 25, 'Male', '8787899987', 'imaging', 'MRI', '458384940404', '2023-08-25', '16:52:00', 2, 10.00),
(4, 'dfnvk', 22, 'Male', '8888888888', 'imaging', 'Ultrasound', '345766780876', '2023-08-25', '16:53:00', 2, 10.00),
(5, 'sunil kumar', 22, 'Male', '9053647890', 'imaging', 'CT Scan', '498192301364', '2023-08-26', '17:26:00', 2, 10.00),
(6, 'dhi', 21, 'Male', '8888888888', 'imaging', 'CT Scan', '458384940404', '2023-08-26', '18:12:00', 2, 10.00),
(7, 'sasa', 45, 'Male', '8787899987', 'imaging', 'Ultrasound', '498192301334', '2023-08-26', '18:30:00', 2, 10.00),
(8, 'ahkf', 45, 'Male', '8847438292', 'imaging', 'CT Scan', '498192301362', '2023-08-26', '18:34:00', 2, 10.00),
(9, 'xskj', 20, 'Male', '9654083988', 'imaging', 'CT Scan', '489056790765', '2023-08-26', '18:42:00', 2, 10.00),
(10, 'sjs', 22, 'Male', '9654083988', 'imaging', 'MRI', '498192300000', '2023-08-26', '18:48:00', 2, 10.00),
(11, 'sharma', 21, 'Male', '9654083988', 'imaging', 'CT Scan', '498192301362', '2023-08-27', '19:39:00', 2, 10.00),
(12, 'safhga387', 23, 'Male', '8888888888', 'imaging', 'CT Scan', '498192301362', '2023-08-28', '01:56:00', 2, 10.00),
(13, 'fdhg23', 31, 'Male', '8864589657', 'imaging', 'CT Scan', '456565678789', '2023-08-28', '02:12:00', 2, 10.00),
(14, 'duy5', 34, 'Male', '9654083988', 'imaging', 'CT Scan', '498192301362', '2023-08-28', '02:14:00', 2, 10.00),
(15, 'sunil kumar', 23, 'Male', '9654083988', 'imaging', 'CT Scan', '498192301362', '2023-08-28', '02:26:00', 2, 10.00),
(16, 'sunil', 18, 'Male', '9654083988', 'imaging', 'CT Scan', '499845678765', '2023-08-28', '02:28:00', 2, 10.00),
(17, 'sunil', 20, 'Male', '9654083988', 'imaging', 'CT Scan', '498192301362', '2023-08-28', '02:40:00', 2, 10.00);

-- --------------------------------------------------------

--
-- Table structure for table `registration_history`
--

CREATE TABLE `registration_history` (
  `id` int(11) NOT NULL,
  `registration_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `ct_count` int(11) NOT NULL,
  `mri_count` int(11) NOT NULL,
  `ultrasound_count` int(11) NOT NULL,
  `total_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sub_departments`
--

CREATE TABLE `sub_departments` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `sub_department_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_departments`
--

INSERT INTO `sub_departments` (`id`, `department_id`, `sub_department_name`) VALUES
(1, 1, 'CT Scan'),
(2, 1, 'Ultrasound'),
(3, 1, 'MRI'),
(7, 3, 'Programming');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `name`, `username`, `password`, `salt`, `enabled`, `last_login`) VALUES
(1, 'admin', 'sunil', 'admin', '$2y$10$auPJ5E8KTHq1ePqi8qP7kOQLddbnZdMefkjYUbRgmF/LXdLGHDIzy', '60e7d97e6123a82abdf55803efb60a38', 1, NULL),
(2, 'operator', 'ajay', 'ajay', '$2y$10$VBqVLBs2LpEXHmAQ7J1aQerQqirajQiLFRS6h4QlMjWVcBjYd3T66', '2dd3844cdc704c9de5d7774d89cfd705', 1, NULL),
(13, 'operator', 'sunil', 'sunil', '$2y$10$t.QaBOtEKuxMEU.cuM07.eDFhfycmS2qNTLgDBx15kZtbLtlbNRge', '9ecfc10c768e24bb88daaa1d4791eb23', 1, NULL),
(14, 'pathologist', 'path', 'path', '$2y$10$yyLS6U.0MYAVPC/1rnlzCOIg4mdz43Un2uwRKdZeQssTFQAMh3O4q', 'bf1885792cfdcd0fb7dfa250768329b7', 1, NULL),
(15, 'operator', 'sunny', 'sunnysinger', '$2y$10$6RHYU6wDkSI0MD.iwxsz9.td28MPJ.wf2Ug1719.S.ys8kdxE.giG', '0d1f2a61061cbaf95fe16b2ac42070a9', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`registration_number`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `registration_history`
--
ALTER TABLE `registration_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sub_departments`
--
ALTER TABLE `sub_departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registration_history`
--
ALTER TABLE `registration_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sub_departments`
--
ALTER TABLE `sub_departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patients`
--
ALTER TABLE `patients`
  ADD CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `registration_history`
--
ALTER TABLE `registration_history`
  ADD CONSTRAINT `registration_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `sub_departments`
--
ALTER TABLE `sub_departments`
  ADD CONSTRAINT `sub_departments_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
