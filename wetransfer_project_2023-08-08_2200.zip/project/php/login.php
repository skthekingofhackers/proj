
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INMAS</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/login.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
        <div class="container-fluid">

            <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 130px;">

            <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
                <BR>PATIENT MEDICAL RECORD
            </h3>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
    <div class="container d-flex justify-content-center align-items-center " style="min-height: 60vh; ">
        <div class="login-table">
            <form method="post" action="authenticate.php">
                <table>
                    <td colspan="5" align="center">
                        <h2>Login</h2>
                    </td>
                    <tr>
                        <th>Login as:</th>
                        <td>
                            <select class="form-select" name="role" required>
                                <option value="">Select</option>
                                <option value="admin" >Admin</option>
                                <option value="pathologist">Pathologist</option>
                                <option value="operator">Operator</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Username:</th>
                        <td><input type="text" class="form-control" name="username" required></td>
                    </tr>
                    <tr>
                        <th>Password:</th>
                        <td><input type="password" class="form-control" name="password" required></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="submit" class="mt-2" value="Login"></td>
                    </tr>
                </table>
            </form>
            <?php
            if (isset($loginError) && $loginError) {
                echo '<p class="error-message">Invalid username or password</p>';
            }
            ?>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/jquery-3.7.0.min.js"></script>
</body>

</html>