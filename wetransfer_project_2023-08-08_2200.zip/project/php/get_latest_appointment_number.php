<?php
// Your database connection details
$servername = "localhost";
$username = "admin";
$password = "admin";
$dbname = "imaging_db";

try {
    // Establishing the database connection using PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch the latest appointment number from the database
    $stmt = $conn->query("SELECT MAX(appointment_number) AS latest_appointment_number FROM patients");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $latestAppointmentNumber = $result['latest_appointment_number'];

    // Return the latest appointment number as a response
    echo $latestAppointmentNumber ? $latestAppointmentNumber : 0;
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Close the database connection
$conn = null;
?>
