function validateForm() {
    const nameInput = document.querySelector('input[name="name"]');
    const ageInput = document.querySelector('input[name="age"]');
    const genderSelect = document.getElementById('gender');
    const contactInput = document.querySelector('input[name="contact"]');
    const departmentSelect = document.getElementById('department');
    const subDepartmentSelect = document.getElementById('sub_department');
    const aadharInput = document.querySelector('input[name="aadhar_no"]');
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');

    if (
        nameInput.value === '' ||
        ageInput.value === '' ||
        genderSelect.value === '' ||
        contactInput.value === '' ||
        departmentSelect.value === '' ||
        subDepartmentSelect.value === '' ||
        aadharInput.value === '' ||
        dateInput.value === '' ||
        timeInput.value === ''
    ) {
        alert('Please fill in all fields before submitting the form.');
        return false;
    }

    return true;
}