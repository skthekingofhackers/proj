function updateCounts() {
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                const data = JSON.parse(xhr.responseText);

                document.getElementById('ctScanCount').innerText = data.ctScanCount;
                document.getElementById('mriCount').innerText = data.mriCount;
                document.getElementById('ultrasoundCount').innerText = data.ultrasoundCount;

                const totalAppointments = data.ctScanCount + data.mriCount + data.ultrasoundCount;
                document.getElementById('totalAppointments').innerText = totalAppointments;
            }
        }
    };
    xhr.open('GET', '../php/count_patients.php', true);
    xhr.send();
}

updateCounts();
setInterval(updateCounts, 10000);