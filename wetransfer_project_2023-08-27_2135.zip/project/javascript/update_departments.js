
function updateDepartmentOptions() {
    var departmentDropdown = document.getElementById("department");

    // Make an AJAX request to fetch updated department options
    $.ajax({
        url: "../php/fetch_departments.php", // Path to the script that fetches departments
        method: "POST", // Use POST method
        dataType: "json",
        success: function (data) {
            // Clear existing options
            departmentDropdown.innerHTML = "";

            // Populate the dropdown with updated options
            for (var i = 0; i < data.length; i++) {
                var option = document.createElement("option");
                option.value = data[i].department_id;
                option.text = data[i].department_name;
                departmentDropdown.appendChild(option);
            }
        },
        error: function (error) {
            console.log("Error fetching department options:", error);
        }
    });
}

// Call the function to update department options on page load
updateDepartmentOptions();
