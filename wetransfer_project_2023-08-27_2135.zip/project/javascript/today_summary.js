
function updateSummaryData() {
    // Make an AJAX request to fetch the latest summary data
    // Replace 'fetch_summary_data.php' with your actual server endpoint
    fetch('../php/today_summary_data.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('ctScanCount').textContent = data.ctScanCount;
            document.getElementById('mriCount').textContent = data.mriCount;
            document.getElementById('ultrasoundCount').textContent = data.ultrasoundCount;
            document.getElementById('totalRegistrations').textContent = data.totalRegistrations;
        })
        .catch(error => console.error('Error fetching summary data:', error));
}

// Call updateSummaryData initially and set an interval to periodically update it
updateSummaryData();
setInterval(updateSummaryData, 5000); // Update every 5 seconds (adjust as needed)