<?php
require_once('db_connection.php'); // Include your database connection initialization

// Get today's date
$todayDate = date('Y-m-d');

// Fetch today's registered patients count
$sqlPatientsToday = "SELECT COUNT(*) as patientsRegistered FROM patients WHERE date = :todayDate";
$stmtPatientsToday = $pdo->prepare($sqlPatientsToday);
$stmtPatientsToday->bindParam(':todayDate', $todayDate, PDO::PARAM_STR);
$stmtPatientsToday->execute();
$resultPatientsToday = $stmtPatientsToday->fetch(PDO::FETCH_ASSOC);

$patientsRegisteredToday = $resultPatientsToday['patientsRegistered'];

// Calculate today's received amount
$sqlAmountToday = "SELECT SUM(amount) as totalAmount FROM payments WHERE date = :todayDate";
$stmtAmountToday = $pdo->prepare($sqlAmountToday);
$stmtAmountToday->bindParam(':todayDate', $todayDate, PDO::PARAM_STR);
$stmtAmountToday->execute();
$resultAmountToday = $stmtAmountToday->fetch(PDO::FETCH_ASSOC);

$receivedAmountToday = $resultAmountToday['totalAmount'];

$dashboardStats = array(
    'patientsRegisteredToday' => $patientsRegisteredToday,
    'receivedAmountToday' => $receivedAmountToday
);

header('Content-Type: application/json');
echo json_encode($dashboardStats);
?>
