<?php
require_once('db_connection.php');
require_once 'navbar.php';

$sql = "SELECT * FROM patients";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$patientRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

$columns = array_keys($patientRecords[0]);

$validSearchColumns = ['registration_number', 'name', 'contact', 'aadhar_no'];

$selectedColumn = '';
$searchValue = '';
$startDate = '';
$endDate = '';

$errorMsg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedColumn = $_POST['column'];
    $searchValue = $_POST['search'];
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];

    if (!in_array($selectedColumn, $validSearchColumns)) {
        $errorMsg = "Invalid column selection.";
    } else {
        $sql = "SELECT * FROM patients WHERE $selectedColumn LIKE :searchValue";

        if (!empty($startDate) && !empty($endDate)) {
            $sql .= " AND date BETWEEN :startDate AND :endDate";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':searchValue', "%$searchValue%", PDO::PARAM_STR);

        if (!empty($startDate) && !empty($endDate)) {
            $stmt->bindValue(':startDate', $startDate);
            $stmt->bindValue(':endDate', $endDate);
        }

        $stmt->execute();
        $patientRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($patientRecords) === 0) {
            $noResultsMsg = "No patients found for the given search criteria.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Records</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
    <script src="../bootstrap/jspdf.min.js"></script>
    <script src="../bootstrap/html2canvas.min.js"></script>
</head>

<body>

    <div class="container mt-4">
        <form class="mb-4" method="POST">
            <div class="input-group">
                <select class="form-select" name="column">
                    <?php foreach ($validSearchColumns as $column) { ?>
                        <option value="<?php echo $column; ?>" <?php if ($selectedColumn === $column) echo 'selected'; ?>>
                            <?php echo ucfirst($column); ?>
                        </option>
                    <?php } ?>
                </select>
                <input type="text" class="form-control" name="search" value="<?php echo $searchValue; ?>" placeholder="Search patient details">

                <label for="start_date" class="form-label">Start Date:</label>
                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $startDate; ?>">

                <label for="end_date" class="form-label">End Date:</label>
                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $endDate; ?>">

                <button type="submit" class="btn btn-primary">Search</button>
            </div>
            <?php if ($errorMsg !== '') { ?>
                <p class="text-danger"><?php echo $errorMsg; ?></p>
            <?php } ?>
        </form>

        <table class="table table-striped table-hover text-center">
            <thead>
                <tr>
                    <?php foreach ($columns as $column) { ?>
                        <th><?php echo ucfirst($column); ?></th>
                    <?php } ?>
                    <th>Download</th>
                    <!--<th>Download</th>-->
                </tr>

            </thead>
            <tbody>
                <?php foreach ($patientRecords as $patient) { ?>
                    <tr>
                        <?php foreach ($columns as $column) { ?>
                            <td><?php echo $patient[$column]; ?></td>
                        <?php } ?>
                        <td>
                            <a href="download_card.php?registration_number=<?php echo $patient['registration_number']; ?>&action=view" class="btn btn-primary btn-sm">View/download</a>
                        </td>
                        <!--<td>
                            <button class="btn btn-primary btn-sm download-button" data-registration="<?php echo $patient['registration_number']; ?>">
                                Download card
                            </button>
                        </td>-->

                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>