<?php
require_once('user_info.php');
require_once('db_connection.php'); // Include your database connection code using PDO
require_once 'navbar.php';
// Check if the user is authenticated and has the 'admin' role
authenticate('admin');
$userRole = $_SESSION['user_role'];
$errorMessage = "";

// Handle enabling or disabling user when the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['userId'];

    try {
        // Toggle user status in the database
        $query = "UPDATE users SET enabled = NOT enabled WHERE id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$userId]);
    } catch (PDOException $e) {
        // Handle database error
        $errorMessage = "Error updating user status: " . $e->getMessage();
    }
}

// Retrieve user data from the database
$query = "SELECT * FROM users";
$stmt = $pdo->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enable/Disable Users</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/login.css">

 <style>
        .container {
            margin-top: 50px;
        }

        .table {
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
        }

        .btn-enable:hover {
            background-color: #28a745; /* Green color on hover */
            border-color: black;
        }

        .btn-disable:hover {
            background-color: #dc3545; /* Red color on hover */
            border-color: black;
        }

        .table-hover tbody tr:hover {
            background-color: #f8f9fa; /* Light gray background on row hover */
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <?php if ($errorMessage) : ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        <table class="table table-success table-striped table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user) : ?>
                    <tr>
                        <td><?php echo $user['name']; ?></td>
                        <td><?php echo $user['username']; ?></td>
                        <td><?php echo $user['role']; ?></td>
                        <td><?php echo ($user['enabled'] ? 'Enabled' : 'Disabled'); ?></td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="userId" value="<?php echo $user['id']; ?>">
                                <button type="submit" class="btn <?php echo ($user['enabled'] ? 'btn-enable' : 'btn-disable'); ?>">
                                    <?php echo ($user['enabled'] ? 'Disable' : 'Enable'); ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>

