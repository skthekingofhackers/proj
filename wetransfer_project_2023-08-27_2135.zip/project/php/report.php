<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Report</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../bootstrap/jspdf.umd.min.js"></script>
    <style>
        .graph-container {
            margin: 20px;
        }
        .report-container {
            margin: 20px;
        }
    </style>
</head>
<body>
<div class="report-container">
    <h2 class="display-4 text-center mt-4">User Report</h2>

    <?php
    require_once 'db_connection.php'; // Include the database connection script

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user_id'])) {
        $user_id = $_POST['user_id'];

        // Fetch user details
        $user_query = "SELECT * FROM users WHERE id = :user_id";
        $user_stmt = $pdo->prepare($user_query);
        $user_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $user_stmt->execute();
        $user = $user_stmt->fetch(PDO::FETCH_ASSOC);

        // Fetch patient data for the user
        $patient_query = "SELECT sub_department, COUNT(*) AS count, SUM(rs_received) AS total_rs
                         FROM patients
                         WHERE user_id = :user_id
                         GROUP BY sub_department";
        $patient_stmt = $pdo->prepare($patient_query);
        $patient_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $patient_stmt->execute();
        $patient_data = $patient_stmt->fetchAll(PDO::FETCH_ASSOC);

        // Prepare data for the graphs
        $sub_departments = [];
        $patient_counts = [];
        $rs_collected = [];
        foreach ($patient_data as $row) {
            $sub_departments[] = $row['sub_department'];
            $patient_counts[] = $row['count'];
            $rs_collected[] = $row['total_rs'];
        }

        // Display user details
        echo '<h3 class="text-dark">User Details</h3>';
        echo '<p class="text-dark">User ID: ' . $user['id'] . '</p>';
        echo '<p class="text-dark">Name: ' . $user['name'] . '</p>';

        // Display graphs in one row
        echo '<div class="d-flex justify-content-center align-items-center" style="height: 400px;">
            <div class="graph-container" style="width: 40%;">
                <canvas id="patientCountChart" class="mr-4"></canvas>
            </div>
            <div class="graph-container" style="width: 40%;">
                <canvas id="rsCollectedChart"></canvas>
            </div>
        </div>';

        // Table for Patient Counts
        echo '<div class="table-responsive mt-4">
            <h4 class="text-dark">Patient Counts Table</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Sub Department</th>
                        <th>Number of Patients</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($patient_data as $row) {
            echo '<tr>
                    <td>' . $row['sub_department'] . '</td>
                    <td>' . $row['count'] . '</td>
                </tr>';
        }
        echo '</tbody></table></div>';

        // Table for Rs Collected
        echo '<div class="table-responsive mt-4">
            <h4 class="text-dark">Rs Collected Table</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Sub Department</th>
                        <th>Total Rs Collected</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($patient_data as $row) {
            echo '<tr>
                    <td>' . $row['sub_department'] . '</td>
                    <td>' . $row['total_rs'] . '</td>
                </tr>';
        }
        echo '</tbody></table></div>';

        // JavaScript for generating graphs
        echo '<script>
            var patientCountChart = new Chart(document.getElementById("patientCountChart"), {
                type: "bar",
                data: {
                    labels: ' . json_encode($sub_departments) . ',
                    datasets: [{
                        label: "Number of Patients",
                        data: ' . json_encode($patient_counts) . ',
                        backgroundColor: [
                            "rgba(65, 105, 225, 0.8)",
                            "rgba(30, 144, 255, 0.8)",
                            "rgba(0, 0, 139, 0.8)"
                        ],
                        borderColor: [
                            "rgba(65, 105, 225, 1)",
                            "rgba(30, 144, 255, 1)",
                            "rgba(0, 0, 139, 1)"
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });

            var rsCollectedChart = new Chart(document.getElementById("rsCollectedChart"), {
                type: "bar",
                data: {
                    labels: ' . json_encode($sub_departments) . ',
                    datasets: [{
                        label: "Rs Collected",
                        data: ' . json_encode($rs_collected) . ',
                        backgroundColor: [
                            "rgba(65, 105, 225, 0.8)",
                            "rgba(30, 144, 255, 0.8)",
                            "rgba(0, 0, 139, 0.8)"
                        ],
                        borderColor: [
                            "rgba(65, 105, 225, 1)",
                            "rgba(30, 144, 255, 1)",
                            "rgba(0, 0, 139, 1)"
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                color: "#333" // Dark font color
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        </script>';
    } else {
        echo '<p class="text-dark">No user selected for generating the report.</p>';
    }
    ?>
    <div class="text-center mt-4">
    <button id="downloadReportBtn" class="btn btn-outline-success">Download Report</button>
    <button onclick="window.print()" class="btn btn-outline-info">Print</button>
</div>
</div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../bootstrap/jspdf.umd.min.js"></script>
    <script>
document.getElementById("downloadReportBtn").addEventListener("click", function() {
    // Create a new jsPDF instance
    const pdf = new window.jspdf.jsPDF();

    // Set the report title
    const reportTitle = "User Report";

    // Get the user details
    const userName = "<?php echo $user['name']; ?>";
    const userId = "<?php echo $user['id']; ?>";

    // Modify the filename to include user's name and ID
    const fileName = "<?php echo $user['name'] . '_' . $user['id'] . '_report.pdf'; ?>";

    // Add the title to the PDF
    pdf.setFontSize(20);
    pdf.text(reportTitle, 105, 20, { align: "center" });

    // Add user details to the PDF
    pdf.setFontSize(14);
    pdf.text(`User ID: ${userId}`, 10, 40);
    pdf.text(`Name: ${userName}`, 10, 50);

    // Get the canvas elements of both charts
    const patientChartCanvas = document.getElementById("patientCountChart");
    const rsChartCanvas = document.getElementById("rsCollectedChart");

    // Convert the canvas elements to images and add to the PDF
    const patientChartImage = patientChartCanvas.toDataURL("image/jpeg", 1.0);
    const rsChartImage = rsChartCanvas.toDataURL("image/jpeg", 1.0);
    pdf.addImage(patientChartImage, "JPEG", 10, 60, 100, 75);
    pdf.addImage(rsChartImage, "JPEG", 110, 60, 100, 75);

    // Save the PDF with the modified filename
    pdf.save(fileName);
});
</script>



</body>
</html>
