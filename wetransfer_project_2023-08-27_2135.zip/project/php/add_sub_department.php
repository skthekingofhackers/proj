<?php
require_once('user_info.php');
authenticate('admin');
include 'db_connection.php'; // Include your database connection
require_once 'navbar.php';
$successMessage = $errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $department = $_POST['department'];
    $subDepartmentName = $_POST['subDepartmentName'];

    // Insert sub-department into the database
    $sql = "INSERT INTO sub_departments (department_id, sub_department_name) VALUES ((SELECT id FROM departments WHERE department_name = :department_name), :sub_department_name)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':department_name', $department);
    $stmt->bindParam(':sub_department_name', $subDepartmentName);

    try {
        $stmt->execute();
        $successMessage = "Sub Department added successfully.";
    } catch (PDOException $e) {
        $errorMessage = "Error adding sub department: " . $e->getMessage();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Sub Department</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
  </head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2 class="text-center">Add Sub Department</h2>
                <?php if ($successMessage) : ?>
                    <div class="alert alert-success"><?php echo $successMessage; ?></div>
                <?php endif; ?>
                <?php if ($errorMessage) : ?>
                    <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                <?php endif; ?>
                <form action="" method="post">
                    <div class="mb-3">
                        <label for="department" class="form-label">Select Department</label>
                        <select class="form-select" id="department" name="department" required>
                            <option value="">Select Department</option>
                            <!-- PHP code to fetch and populate department options -->
                            <?php
                            $sql = "SELECT department_name FROM departments";
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute();

                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['department_name'] . '">' . $row['department_name'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="subDepartmentName" class="form-label">Sub Department Name</label>
                        <input type="text" class="form-control" id="subDepartmentName" name="subDepartmentName" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Sub Department</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../javascript/update_departments.js"></script>
</body>
</html>
