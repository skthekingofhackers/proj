<?php
// fetch_departments.php

// Include your database connection code using PDO
require_once('db_connection.php');

// Fetch department options from the database
$query = "SELECT department_id, department_name FROM departments";
$stmt = $pdo->prepare($query);
$stmt->execute();
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Return the department options as JSON
header('Content-Type: application/json');
echo json_encode($departments);
?>
