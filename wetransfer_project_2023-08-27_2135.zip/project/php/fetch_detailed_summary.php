<?php
// Include the database connection file
require_once('db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['fromDate']) && isset($_GET['toDate'])) {
    $fromDate = $_GET['fromDate'];
    $toDate = $_GET['toDate'];

    $sql = "SELECT patients.*, users.name AS user_name
            FROM patients
            INNER JOIN users ON patients.user_id = users.id
            WHERE patients.date BETWEEN :fromDate AND :toDate";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':fromDate', $fromDate);
    $stmt->bindParam(':toDate', $toDate);
    $stmt->execute();
    
    $detailedSummary = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(array("detailedSummary" => $detailedSummary));
} else {
    echo json_encode(array("error" => "Invalid request"));
}

// Close the database connection
$conn = null;
?>
