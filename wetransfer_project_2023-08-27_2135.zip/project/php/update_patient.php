<?php
// Include the database connection file
require_once('db_connection.php');

try {
    $department = $_POST['department_name'];
    $subDepartment = $_POST['sub_department'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $aadharNo = $_POST['aadhar_no'];
    $registrationNumber = $_POST['registration_number'];

    $sql = "UPDATE patients SET department = :department, sub_department = :sub_department,
            name = :name, age = :age, gender = :gender, contact = :contact, aadhar_no = :aadhar_no
            WHERE registration_number = :registration_number";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':department', $department);
    $stmt->bindParam(':sub_department', $subDepartment);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':age', $age);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':contact', $contact);
    $stmt->bindParam(':aadhar_no', $aadharNo);
    $stmt->bindParam(':registration_number', $registrationNumber);

    $stmt->execute();

    // Redirect back to the display page
    header("Location: edit_page.php");
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
