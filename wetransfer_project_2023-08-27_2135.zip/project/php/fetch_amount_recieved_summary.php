<?php
require_once 'db_connection.php'; // Include the database connection script

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $fromDate = $_GET["fromDate"];
    $toDate = $_GET["toDate"];

    $amountReceivedSummary = [];

    // Fetch amount received summary data
    $subDeptQuery = "SELECT sub_department, SUM(rs_received) AS rsReceived
                     FROM patients
                     WHERE date BETWEEN :fromDate AND :toDate
                     GROUP BY sub_department";
    $subDeptStmt = $pdo->prepare($subDeptQuery);
    $subDeptStmt->bindParam(':fromDate', $fromDate);
    $subDeptStmt->bindParam(':toDate', $toDate);
    $subDeptStmt->execute();
    $subDeptData = $subDeptStmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($subDeptData as $row) {
        $amountReceivedSummary[] = [
            "name" => $row['sub_department'],
            "rsReceived" => $row['rsReceived']
        ];
    }

    // Return amount received summary data as JSON response
    header('Content-Type: application/json');
    echo json_encode(["amountReceived" => $amountReceivedSummary]);
}
?>
