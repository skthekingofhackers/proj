<?php
require_once('user_info.php'); // Include the user_info.php file
authenticate('admin');
require_once 'navbar.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brief Summary</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center">Brief Summary</h2>
        <div class="row mt-3">
            <div class="col-md-4">
                <label for="fromDate">From Date:</label>
                <input type="date" id="fromDate" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="toDate">To Date:</label>
                <input type="date" id="toDate" class="form-control">
            </div>
            <div class="col-md-4">
                <button id="generateSummaryBtn" class="btn btn-primary mt-4">Generate Summary</button>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <h4>Brief Summary of Patients</h4>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Sub-Department</th>
                            <th>No. of Patients</th>
                        </tr>
                    </thead>
                    <tbody id="patientsSummary">
                        <!-- Patients summary data will be dynamically added here -->
                    </tbody>
                </table>
                <h5>Total Patients: <span id="totalPatientsCount">0</span></h5>
            </div>
            <div class="col-md-6">
                <h4>Brief Summary of Amount Received</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Sub-Department</th>
                            <th>Rs Received</th>
                        </tr>
                    </thead>
                    <tbody id="amountReceivedSummary">
                        <!-- Amount received summary data will be dynamically added here -->
                    </tbody>
                </table>
                <h5>Total Rs Received: <span id="totalRsReceived">0</span></h5>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $("#generateSummaryBtn").click(function () {
                var fromDate = $("#fromDate").val();
                var toDate = $("#toDate").val();

                // Fetch and display patients summary data
                $.ajax({
                    type: "GET",
                    url: "fetch_patients_summary.php",
                    data: { fromDate: fromDate, toDate: toDate },
                    dataType: "json",
                    success: function (data) {
                        var patientsSummaryHtml = "";
                        var totalPatients = 0;

                        $.each(data.patients, function (index, subDept) {
                            patientsSummaryHtml += "<tr>";
                            patientsSummaryHtml += "<td>" + subDept.name + "</td>";
                            patientsSummaryHtml += "<td>" + subDept.patientCount + "</td>";
                            patientsSummaryHtml += "</tr>";
                            totalPatients += parseInt(subDept.patientCount);
                        });

                        $("#patientsSummary").html(patientsSummaryHtml);
                        $("#totalPatientsCount").text(totalPatients);
                    }
                });

                // Fetch and display amount received summary data
                $.ajax({
                    type: "GET",
                    url: "fetch_amount_received_summary.php",
                    data: { fromDate: fromDate, toDate: toDate },
                    dataType: "json",
                    success: function (data) {
                        var amountReceivedSummaryHtml = "";
                        var totalRsReceived = 0;

                        $.each(data.amountReceived, function (index, subDept) {
                            amountReceivedSummaryHtml += "<tr>";
                            amountReceivedSummaryHtml += "<td>" + subDept.name + "</td>";
                            amountReceivedSummaryHtml += "<td>" + subDept.rsReceived + "</td>";
                            amountReceivedSummaryHtml += "</tr>";
                            totalRsReceived += parseInt(subDept.rsReceived);
                        });

                        $("#amountReceivedSummary").html(amountReceivedSummaryHtml);
                        $("#totalRsReceived").text(totalRsReceived);
                    }
                });
            });
        });
    </script>
        <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>
