<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <script src="../bootstrap/css/bootstrap.min.css"></script>
    <style>
body {
    /* Gradient from top (#4CAF50) to bottom (#2196F3) */
    background-color: azure;
    /* Optional: Set the text color to white for better readability on the gradient background */
    /* Optional: Set some padding and center the content */
    font-family: 'Times New Roman', Times, serif;
    background-repeat: no-repeat;
    background-size: auto;
}

h2{
    background: repeating-radial-gradient(circle closest-corner at 100px 100px,#000000, #ee4b2b 10%, #553c9a 20%);
    -webkit-text-fill-color: transparent;
    -webkit-background-clip: text;
    background-clip: text;

}

.navbar-custom {
    background: linear-gradient(to right, #050730, #4a4acb);
    /* Replace the colors with your desired gradient */
}

.navbar-custom .navbar-heading {
    color: #ffffff;
    margin-right: auto;
    margin-top: 0%;
}

.custom-btn {
    transition: background-color 0.3s ease;
}

a:hover {
    background-color: #93b5ff;
    border-radius: 5px;
}

.text-color{
    color: #ffffff;
}

.navbar-nav .nav-link {
    color: black; /* Change the color to black */
}

    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">
      <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">
      <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
        <BR>PATIENT MEDICAL RECORD
      </h3>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </nav>
  <nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
      <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
        <ul class="navbar-nav">
        <?php if ($userRole === 'operator'): ?>
          <li class="nav-item active">
            <a class="nav-link" href="operator.php" role="button" aria-expanded="false">  
            <b>Dashboard</b>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="my_summary.php" role="button" aria-expanded="false">  
            <b>My Report</b>
            </a>
          </li>
          <?php endif; ?>
          <?php if ($userRole === 'admin'): ?>
          <li class="nav-item active">
            <a class="nav-link" href="admin.php" role="button" aria-expanded="false">  
            <b>Dashboard</b>
            </a>
          </li>
          <?php endif; ?>
          <?php if ($userRole === 'admin' || $userRole === 'operator'): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <b>Registration</b>
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
                <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
                <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
                <li><a class="dropdown-item" href="brief_summary.php"><b>Brief summary</b></a></li>
                <li><a class="dropdown-item" href="detailed_summary.php"><b>Detailed summary</b></a>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <b>Profile</b>
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="change_username.php"><b>Change username</b></a></li>
                <li><a class="dropdown-item" href="change_password.php"><b>Change password</b></a></li>
                <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
              </ul>
            </li>
          <?php endif; ?>
          <?php if ($userRole === 'admin'): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <b>Master</b>
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
                <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
                <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
                <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
                <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a>
                </li>
              </ul>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>

</body>
</html>