<?php
require_once 'db_connection.php';

$selectedDepartment = $_GET['department']; // Make sure to sanitize this input
$subDepartments = array();

// Fetch sub-departments based on the selected department
$sql = "SELECT sub_department_name FROM sub_departments WHERE department_id = (
    SELECT id FROM departments WHERE department_name = :department_name
)";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':department_name', $selectedDepartment, PDO::PARAM_STR);
    $stmt->execute();

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $subDepartments[] = $row['sub_department_name'];
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$pdo = null;

// Return the data as JSON
echo json_encode($subDepartments);
?>
