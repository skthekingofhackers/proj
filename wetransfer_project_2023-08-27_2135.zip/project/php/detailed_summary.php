<?php
require_once('user_info.php'); // Include the user_info.php file
authenticate('admin');
require_once 'navbar.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detailed Summary</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <style>
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .summary-table {
            margin-top: 30px;
        }

        .table-hover-shadow {
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .user-details {
            font-size: 14px;
            color: #888;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2>Detailed Summary</h2>
        <div class="row mt-3">
            <div class="col-md-4">
                <label for="fromDate">From Date:</label>
                <input type="date" id="fromDate" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="toDate">To Date:</label>
                <input type="date" id="toDate" class="form-control">
            </div>
            <div class="col-md-4">
                <button id="generateSummaryBtn" class="btn btn-primary mt-4">Generate Summary</button>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <h4>Detailed Patient Summary</h4>
                <table class="table table-hover table-hover-shadow">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Sub-Department</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Contact</th>
                            <th>Registered By</th>
                        </tr>
                    </thead>
                    <tbody id="detailedSummary">
                        <!-- Detailed summary data will be dynamically added here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            $("#generateSummaryBtn").click(function () {
                var fromDate = $("#fromDate").val();
                var toDate = $("#toDate").val();

                // Fetch and display detailed summary data
                $.ajax({
                    type: "GET",
                    url: "fetch_detailed_summary.php",
                    data: { fromDate: fromDate, toDate: toDate },
                    dataType: "json",
                    success: function (data) {
                        var detailedSummaryHtml = "";

                        $.each(data.detailedSummary, function (index, entry) {
                            detailedSummaryHtml += "<tr>";
                            detailedSummaryHtml += "<td>" + entry.date + "</td>";
                            detailedSummaryHtml += "<td>" + entry.time + "</td>";
                            detailedSummaryHtml += "<td>" + entry.sub_department + "</td>";
                            detailedSummaryHtml += "<td>" + entry.name + "</td>";
                            detailedSummaryHtml += "<td>" + entry.age + "</td>";
                            detailedSummaryHtml += "<td>" + entry.gender + "</td>";
                            detailedSummaryHtml += "<td>" + entry.contact + "</td>";
                            detailedSummaryHtml += "<td class='user-details'>" + entry.user_name + "</td>";
                            detailedSummaryHtml += "</tr>";
                        });

                        $("#detailedSummary").html(detailedSummaryHtml);
                    }
                });
            });
        });
    </script>
</body>

</html>
