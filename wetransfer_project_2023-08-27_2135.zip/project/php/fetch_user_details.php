<?php
// Include the database connection file
require_once('db_connection.php');

try {
    // Fetch user details from the users table
    $stmt = $pdo->query("SELECT id, name, role FROM users WHERE enabled = 1"); // Fetch only enabled users

    $userDetails = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $userDetails[] = $row;
    }

    // Return the user details as JSON response
    echo json_encode(['userDetails' => $userDetails]);
} catch (PDOException $e) {
    http_response_code(500); // Set HTTP response code to indicate server error
    echo "Error: Connection failed.";
}

// Close the database connection
$conn = null;
?>
