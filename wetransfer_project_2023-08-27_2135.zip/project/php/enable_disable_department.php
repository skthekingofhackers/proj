<?php
require_once 'user_info.php';
authenticate('admin');
include ('db_connection.php'); // Include your database connection
require_once 'navbar.php';
$userRole = $_SESSION['user_role'];
$successMessage = $errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $departmentId = $_POST['departmentId'];
    $newStatus = $_POST['newStatus'];

    // Update department status in the database
    $sql = "UPDATE departments SET enabled = :new_status WHERE id = :department_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':new_status', $newStatus, PDO::PARAM_INT);
    $stmt->bindParam(':department_id', $departmentId, PDO::PARAM_INT);

    try {
        $stmt->execute();
        if ($newStatus == 0) {
            $successMessage = "Department disabled successfully.";
        } else {
            $successMessage = "Department enabled successfully.";
        }
    } catch (PDOException $e) {
        $errorMessage = "Error updating department status: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enable/Disable Department</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
  </head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2 class="text-center">Enable/Disable Department</h2>
                <?php if ($successMessage) : ?>
                    <div class="alert alert-success"><?php echo $successMessage; ?></div>
                <?php endif; ?>
                <?php if ($errorMessage) : ?>
                    <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                <?php endif; ?>
                <form action="" method="post">
                    <div class="mb-3">
                        <label for="departmentId" class="form-label">Select Department</label>
                        <select class="form-select" id="departmentId" name="departmentId" required>
                            <option value="">Select Department</option>
                            <!-- PHP code to fetch and populate department options -->
                            <?php
                            $sql = "SELECT id, department_name FROM departments";
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute();

                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['id'] . '">' . $row['department_name'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="newStatus" class="form-label">New Status</label>
                        <select class="form-select" id="newStatus" name="newStatus" required>
                            <option value="0">Disable</option>
                            <option value="1">Enable</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Status</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../javascript/update_departments.js"></script>
</body>
</html>
