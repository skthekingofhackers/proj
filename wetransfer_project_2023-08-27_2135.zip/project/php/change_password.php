<?php
require_once 'user_info.php'; // Include the user_info.php file
authenticate(['admin', 'operator']);

// Include your database connection initialization
require_once('db_connection.php');
require_once 'navbar.php';
$successMessage = "";
$errorMessage = "";

// Function to retrieve hashed password for a user
function getUserPassword($userId) {
    // Replace this with your database connection initialization
    require_once('db_connection.php');

    $sql = "SELECT password FROM users WHERE id = :user_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();

    return $user['password'];
}

// Function to update user password
function updateUserPassword($userId, $newHashedPassword) {
    // Replace this with your database connection initialization
    require_once('db_connection.php');

    $sql = "UPDATE users SET password = :new_password WHERE id = :user_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':new_password', $newHashedPassword, PDO::PARAM_STR);
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->execute();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentPassword = $_POST['currentPassword'];
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];

    // Assuming you have a user authentication system
    // Replace these placeholders with your actual logic
    $loggedInUserId = $_SESSION['user_id']; // Get the logged-in user's ID
    $userCurrentPassword = getUserPassword($loggedInUserId);

    // Check if the entered current password matches the user's stored password
    if (password_verify($currentPassword, $userCurrentPassword)) {
        // Check if new password and confirm password match
        if ($newPassword === $confirmPassword) {
            // Hash the new password before storing
            $newHashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            // Update user password using the function
            updateUserPassword($loggedInUserId, $newHashedPassword);
            
            $successMessage = "Password changed successfully!";
        } else {
            $errorMessage = "New password and confirm password do not match.";
        }
    } else {
        $errorMessage = "Current password is incorrect.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .containerhere {
            max-width: 400px;
            margin: 100px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            animation: fadein 1s ease-in-out forwards;
            opacity: 0;
            visibility: hidden;
        }

        .success-message,
        .error-message {
            display: none;
            margin-top: 10px;
        }

        .success i,
        .error i {
            margin-right: 5px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
        @keyframes fadein {
            to {
                opacity: 1;
                visibility: visible;
            }
        }
    </style>
</head>
<body>
    <div class="containerhere">
        <h2><i class="fas fa-key"></i> Change Password</h2>
        <form id="changePasswordForm">
            <div class="form-group">
                <label for="currentPassword">Current Password:</label>
                <input type="password" class="form-control" id="currentPassword" required>
            </div>
            <div class="form-group">
                <label for="newPassword">New Password:</label>
                <input type="password" class="form-control" id="newPassword" required>
            </div>
            <div class="form-group">
                <label for="confirmPassword">Confirm Password:</label>
                <input type="password" class="form-control" id="confirmPassword" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-check"></i> Submit
            </button>
            <button type="button" class="btn btn-secondary btn-back">
                <i class="fas fa-arrow-left"></i> Back
            </button>
        </form>
        <div class="success-message">
            <p class="success"><i class="fas fa-check-circle"></i> Password changed successfully!</p>
        </div>
        <div class="error-message">
            <p class="error"><i class="fas fa-times-circle"></i> Password change failed. Please check your input.</p>
        </div>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script>
        document.getElementById("changePasswordForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var currentPassword = document.getElementById("currentPassword").value;
            var newPassword = document.getElementById("newPassword").value;
            var confirmPassword = document.getElementById("confirmPassword").value;

            if (newPassword === confirmPassword) {
                // Password change success
                document.querySelector(".success-message").style.display = "block";
                document.querySelector(".error-message").style.display = "none";
            } else {
                // Password change error
                document.querySelector(".success-message").style.display = "none";
                document.querySelector(".error-message").style.display = "block";
            }
        });

        document.querySelector(".btn-back").addEventListener("click", function() {
            window.history.back();
        });
    </script>
</body>
</html>
