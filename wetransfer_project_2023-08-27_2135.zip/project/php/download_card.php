<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Medical Card</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script src="../bootstrap/jspdf.umd.min.js"></script>
    <script src="../bootstrap/html2canvas.min.js"></script>

    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: rgb(162, 255, 170);
        }

        .medical-card {
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
            margin-top: 20px;
        }

        .medical-card h2 {
            margin-top: 0;
        }

        .medical-card p {
            margin: 10px 0;
        }

        .btn {
            align-items: center;
        }
    </style>
</head>

<body>
    <div class="container card col-sm-6 justify-content-center border-primary mt-3 shadow-lg ">
        <div id="generatepdf">
            <div class="card-header text-center">
                <div style="display: flex; align-items: center;">
                    <img src="../images/logo.png" alt="Card Header Image" style="max-width: 100px; margin-right: 10px;">
                    <h1>Registration Card</h1>
                </div>
            </div>

            <?php
            if (isset($_GET['registration_number']) && isset($_GET['action'])) {
                $registration_number = $_GET['registration_number'];
                $action = $_GET['action'];

                // Fetch patient data using the registration number
                require_once('db_connection.php'); // Include your database connection code
                $sql = "SELECT * FROM patients WHERE registration_number = :registration_number";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':registration_number', $registration_number, PDO::PARAM_INT);
                $stmt->execute();
                $patient = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($action === 'view') {
                    echo "<div class=\"card-body\">
                        <p><strong>Name:</strong> {$patient['name']}</p>
                        <p><strong>Phone Number:</strong> {$patient['contact']}</p>
                        <p><strong>Registration Number:</strong> {$patient['registration_number']}</p>
                        <p><strong>Age:</strong> {$patient['age']}</p>
                        <p><strong>Gender:</strong> {$patient['gender']}</p>
                        <p><strong>Date of registration:</strong> {$patient['date']}</p>
                    </div>";
                } elseif ($action === 'download') {
                    echo "<div class=\"card-body\">
                        <p><strong>Name:</strong> {$patient['name']}</p>
                        <p><strong>Phone Number:</strong> {$patient['contact']}</p>
                        <p><strong>Registration Number:</strong> {$patient['registration_number']}</p>
                        <p><strong>Age:</strong> {$patient['age']}</p>
                        <p><strong>Gender:</strong> {$patient['gender']}</p>
                        <p><strong>Date of registration:</strong> {$patient['date']}</p>
                        </div>";
                }
            } else {
                echo "Invalid request.";
            }
            ?>
        </div>
    </div>

    <div class="text-center">
        <button class="btn btn-info mt-4" id="pdfButton">Download/print PDF</button>
        <a class="btn btn-info mt-4" href="../php/duplicate_card.php">Back</a>
    </div>

    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script>
        window.onload = function() {
            document.getElementById("pdfButton").addEventListener("click", function() {
                const pdf = new window.jspdf.jsPDF("landscape"); // Use the full path to the jsPDF object
                

                const element = document.getElementById("generatepdf");

                html2canvas(element).then(function(canvas) {
                    const imgData = canvas.toDataURL("image/png");

                    // Adjust the image size (width and height) in the PDF
                    const pdfWidth = 150; // Adjust this value
                    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

                    // Center the image horizontally
                    const marginLeft = (pdf.internal.pageSize.width - pdfWidth) / 2;

                    // Calculate the vertical position for the image
                    const marginTop = 20; // Adjust this value

                    // Add the image with border
                    pdf.rect(marginLeft - 5, marginTop - 5, pdfWidth + 10, pdfHeight + 10, "S"); // Add border
                    pdf.addImage(imgData, "PNG", marginLeft, marginTop, pdfWidth, pdfHeight);

                    pdf.save("card.pdf");
                });
            });
        };
    </script>

</body>

</html>