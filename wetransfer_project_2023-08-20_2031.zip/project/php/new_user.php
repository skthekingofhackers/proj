<?php
require_once 'user_info.php';
require_once 'db_connection.php'; // Include your database connection code using PDO

// Check if the user is authenticated and has the 'admin' role
authenticate('admin');

$successMessage = ""; // Initialize an empty success message

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user inputs from the form
    $role = $_POST['role'];
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        // Check if the username already exists in the database
        $query = "SELECT COUNT(*) as count FROM users WHERE username = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$username]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result['count'] > 0) {
            $errorMessage = "Username already exists.";
        } else {
            // Generate a random salt
            $salt = bin2hex(random_bytes(16));

            // Combine the password and salt, then hash them
            $hashedPassword = password_hash($password . $salt, PASSWORD_DEFAULT);

            // Insert new user into the database using PDO
            $query = "INSERT INTO users (role, name, username, password, salt) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$role, $name, $username, $hashedPassword, $salt]);

            // User created successfully
            $successMessage = "User created successfully with the username: " . $username;
        }
    } catch (PDOException $e) {
        // Handle database error
        $errorMessage = "Error creating user: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New User</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/new_user.css">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">
        <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">
        <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
            <BR>PATIENT MEDICAL RECORD
        </h3>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>
<nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
                        <b>Dashboard</b>
                    </a>
                </li>
                <?php if ($userRole === 'admin' || $userRole === 'operator'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Registration</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
                        <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
                        <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
                        <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
                        <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Profile</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#"><b>Change username</b></a></li>
                        <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
                        <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if ($userRole === 'admin'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Master</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
                        <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
                        <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
                        <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
                        <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a></li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
    <div id="successMessageContainer" class="alert alert-success alert-dismissible" style="display: <?php echo $successMessage ? 'block' : 'none'; ?>;">
        <?php echo $successMessage; ?>
    </div>
    <div class="center">
        <div class="card">
            <div class="card-header">
                <h2 class="mb-0" align="center"><b>Create New User</b></h2>
            </div>
            <div class="card-body">
                <form action="" id="registrationForm" method="post">
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <div class="select-arrow">
                            <select class="form-control" id="role" name="role" required>
                                <option value="" disabled selected>Select Role</option>
                                <option value="operator">Operator</option>
                                <option value="admin">Admin</option>
                                <option value="pathologist">Pathologist</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                            required>
                        <small id="passwordMatchError" class="form-text text-danger"
                            style="display: none;">Passwords do not match.</small>
                    </div>
                    <button type="submit" class="btn btn-outline-primary"onclick="return validateForm();"><b>Create User</b></button>
                    <button type="reset" class="btn btn-outline-danger" onclick="resetSuccessMessage();"><b>Reset</b></button>
                </form>
            </div>
        </div>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script>
        function resetSuccessMessage() {
            var successMessageContainer = document.getElementById("successMessageContainer");
            successMessageContainer.style.display = "none";
            successMessageContainer.innerHTML = ""; // Clear the content
        }
        function validateForm() {
            var passwordInput = document.getElementById("password");
            var confirmInput = document.getElementById("confirm_password");
            var passwordMatchError = document.getElementById("passwordMatchError");

            if (passwordInput.value !== confirmInput.value) {
                passwordMatchError.style.display = "block";
                return false; // Prevent form submission
            } else {
                passwordMatchError.style.display = "none";
                return true; // Allow form submission
            }
        }
    </script>

</body>

</html>