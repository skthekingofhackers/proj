<?php
require_once('user_info.php'); // Include the user_info.php file
authenticate('admin');

// Get the user role from the session
include 'db_connection.php'; // Include your database connection
$userRole = $_SESSION['user_role'];

authenticate('admin');
$successMessage = $errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $departmentName = $_POST['departmentName'];

    // Insert department into the database
    $sql = "INSERT INTO departments (department_name) VALUES (:department_name)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':department_name', $departmentName);

    try {
        $stmt->execute();
        $successMessage = "Department added successfully.";
    } catch (PDOException $e) {
        $errorMessage = "Error adding department: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Department</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
  </head>
<body>
<nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">
        <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">
        <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
            <BR>PATIENT MEDICAL RECORD
        </h3>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>
<nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
                        <b>Dashboard</b>
                    </a>
                </li>
                <?php if ($userRole === 'admin' || $userRole === 'operator'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Registration</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
                        <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
                        <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
                        <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
                        <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Profile</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#"><b>Change username</b></a></li>
                        <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
                        <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if ($userRole === 'admin'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Master</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
                        <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
                        <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
                        <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
                        <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a></li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2 class="text-center">Add Department</h2>
                <?php if ($successMessage) : ?>
                    <div class="alert alert-success"><?php echo $successMessage; ?></div>
                <?php endif; ?>
                <?php if ($errorMessage) : ?>
                    <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                <?php endif; ?>
                <form action="" method="post">
                    <div class="mb-3">
                        <label for="departmentName" class="form-label">Department Name</label>
                        <input type="text" class="form-control" id="departmentName" name="departmentName" required>
                    </div>
                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary">Add Department</button>
                        <a href="previous_page.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../javascript/update_departments.js"></script>
</body>
</html>
