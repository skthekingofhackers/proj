<?php
require_once('auth.php');
authenticate('pathologist');

// Rest of your pathologist page code
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INMAS</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/login.css">
    <link rel="stylesheet" href="../css/register.css">

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">

      <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">

      <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
        <BR>PATIENT MEDICAL RECORD
      </h3>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </nav>
  <nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
      <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
        <ul class="navbar-nav">
        <li class="nav-item "> <!-- Add 'active' class here -->
        <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
            <b>Dashboard</b>
        </a>
        </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
             <b>Registration</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
              <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
              <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
              <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
              <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a></li>

            </ul>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <b>Profile</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#"><b>Change username</b></a></li>
              <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
              <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
            </ul>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <b>Master</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
              <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
              <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
              <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
              <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
    <p align="center">WELCOME ..PATHOLOGIST NAME....</p>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/jquery.min.js"></script>
</body>

</html>