<?php
require_once 'db_connection.php'; // Include your PDO database connection

date_default_timezone_set("Asia/Kolkata");

try {
    $today = date("Y-m-d");

    $subDepartments = array('CT Scan', 'MRI', 'Ultrasound');
    $data = array();

    foreach ($subDepartments as $subDept) {
        $sql = "SELECT COUNT(*) FROM patients WHERE sub_department = ? AND DATE_FORMAT(date, '%Y-%m-%d') = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$subDept, $today]);
        $count = $stmt->fetchColumn();

        $data[$subDept . 'Count'] = $count;
    }

    // Close the database connection
    $pdo = null;

    header('Content-Type: application/json');
    echo json_encode($data);
} catch (PDOException $e) {
    $response = array(
        'status' => 'error',
        'message' => $e->getMessage()
    );

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
