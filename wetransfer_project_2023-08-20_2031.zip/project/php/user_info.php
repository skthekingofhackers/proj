<?php
session_start();

// Check if the user is authenticated and has the required role
function authenticate($allowedRoles) {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
        header("Location: login.php");
        exit();
    }
}

// Retrieve user role
$userRole = $_SESSION['user_role'];
?>

