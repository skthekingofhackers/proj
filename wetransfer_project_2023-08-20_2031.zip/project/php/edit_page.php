<?php

require_once('user_info.php'); // Include the user_info.php file
authenticate(['admin','operator']);
require_once('db_connection.php'); 

// Fetch all patient records
$sql = "SELECT * FROM patients";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$patientRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get column names from patients table
$columns = array_keys($patientRecords[0]);

// Define valid search columns
$validSearchColumns = ['registration_number', 'name', 'contact', 'aadhar_no'];

// Initialize variables for search
$selectedColumn = '';
$searchValue = '';

// Initialize error message
$errorMsg = '';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedColumn = $_POST['column'];
    $searchValue = $_POST['search'];

    // Validate selected column
    if (!in_array($selectedColumn, $validSearchColumns)) {
        $errorMsg = "Invalid column selection.";
    } else {
        // Perform search query using the selected column and search value
        if ($selectedColumn === 'registration_number') {
            // Use equality comparison for registration_number
            $sql = "SELECT * FROM patients WHERE $selectedColumn = :searchValue";
        } else {
            // Use LIKE for other columns
            $sql = "SELECT * FROM patients WHERE $selectedColumn LIKE :searchValue";
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':searchValue', $searchValue, PDO::PARAM_STR);
        $stmt->execute();
        $patientRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if no patients were found
        if (count($patientRecords) === 0) {
            $noResultsMsg = "No patients found for the given search criteria.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Records</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">

  </head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">
        <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">
        <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
            <BR>PATIENT MEDICAL RECORD
        </h3>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>
<nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
                        <b>Dashboard</b>
                    </a>
                </li>
                <?php if ($userRole === 'admin' || $userRole === 'operator'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Registration</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
                        <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
                        <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
                        <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
                        <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Profile</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#"><b>Change username</b></a></li>
                        <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
                        <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if ($userRole === 'admin'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <b>Master</b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
                        <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
                        <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
                        <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
                        <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a></li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <form class="mb-4" method="POST">
        <div class="input-group">
            <select class="form-select" name="column">
                <?php foreach ($validSearchColumns as $column) { ?>
                    <option value="<?php echo $column; ?>" <?php if ($selectedColumn === $column) echo 'selected'; ?>>
                        <?php echo ucfirst($column); ?>
                    </option>
                <?php } ?>
            </select>
            <input type="text" class="form-control" name="search" value="<?php echo $searchValue; ?>" placeholder="Search patient details">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
        <?php if ($errorMsg !== '') { ?>
            <p class="text-danger"><?php echo $errorMsg; ?></p>
        <?php } ?>
    </form>

    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <?php foreach ($columns as $column) { ?>
                    <th><?php echo ucfirst($column); ?></th>
                <?php } ?>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($patientRecords as $patient) { ?>
            <tr>
                <?php foreach ($columns as $column) { ?>
                    <td><?php echo $patient[$column]; ?></td>
                <?php } ?>
                <td>
                    <a href="updateform.php?registration_number=<?php echo $patient['registration_number']; ?>"
                       class="btn btn-primary btn-sm">Edit</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Other scripts and content -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
