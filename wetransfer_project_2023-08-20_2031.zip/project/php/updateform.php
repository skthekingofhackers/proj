<?php
require_once 'user_info.php';

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient Details</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/login.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
        <div class="container-fluid">

            <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">

            <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
                <BR>PATIENT MEDICAL RECORD
            </h3>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
    <nav class="navbar navbar-expand-lg"
        style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
        <div class="container">
            <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item "> <!-- Add 'active' class here -->
                        <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
                            <b>Dashboard</b>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <b>Registration</b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../html/register.html"><b>New Registration</b></a></li>
                            <li><a class="dropdown-item" href="../html/display.html"><b>Edit</b></a></li>
                            <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
                            <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
                            <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a>
                            </li>

                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <b>Profile</b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
                            <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <b>Master</b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
                            <li><a class="dropdown-item" href="#"><b>Add department</b></a></li>
                            <li><a class="dropdown-item" href="#"><b>Enable/ disable user</b></a></li>
                            <li><a class="dropdown-item" href="#"><b>Enable/ disable department</b></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <?php
        require_once('db_connection.php');

        try {
            $registrationNumber = $_GET['registration_number'];
            $sql = "SELECT * FROM patients WHERE registration_number = :registration_number";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':registration_number', $registrationNumber);
            $stmt->execute();
            $patientData = $stmt->fetch(PDO::FETCH_ASSOC);

            // Fetch enabled departments for dynamic dropdown
            $departmentsSql = "SELECT department_name FROM departments WHERE enabled = 1";
            $departmentsStmt = $pdo->prepare($departmentsSql);
            $departmentsStmt->execute();
            $departments = $departmentsStmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $department = $_POST['department'];
                $subDepartment = $_POST['sub_department'];
                $name = $_POST['name'];
                $age = $_POST['age'];
                $gender = $_POST['gender'];
                $contact = $_POST['contact'];
                $aadharNo = $_POST['aadhar_no'];

                $updateSql = "UPDATE patients SET department = :department, sub_department = :sub_department,
                        name = :name, age = :age, gender = :gender, contact = :contact, aadhar_no = :aadhar_no
                        WHERE registration_number = :registration_number";

                $updateStmt = $pdo->prepare($updateSql);
                $updateStmt->bindParam(':department', $department);
                $updateStmt->bindParam(':sub_department', $subDepartment);
                $updateStmt->bindParam(':name', $name);
                $updateStmt->bindParam(':age', $age);
                $updateStmt->bindParam(':gender', $gender);
                $updateStmt->bindParam(':contact', $contact);
                $updateStmt->bindParam(':aadhar_no', $aadharNo);
                $updateStmt->bindParam(':registration_number', $registrationNumber);

                $updateStmt->execute();

                // Check if rows were affected
                if ($updateStmt->rowCount() > 0) {
                    echo '<div id="successMessage" class="alert alert-success alert-dismissible">Patient details updated successfully.</div>';
                } else {
                    echo '<div id="successMessage" class="alert alert-danger alert-dismissible">Failed to update patient details.</div>';
                }
            } catch (PDOException $e) {
                echo '<div id="successMessage" class="alert alert-danger alert-dismissible">Error: ' . $e->getMessage() . '</div>';
            }
        }
        ?>
        <form method="post" action="" id="editForm">
            <table align="center" class="table table-striped table-bordered">
                <h2 align='center' class="display-5 text-uppercase font-monospace">Edit Patient Details</h2>
                <tr>
                    <td>Department:</td>
                    <td class="form-control">
                        <select class="form-select" aria-label="Small select example" id="department" name="department"
                            required>
                            <option value="">Select Department</option>
                            <?php
                            foreach ($departments as $dept) {
                                $isSelected = ($dept['department_name'] === $patientData['department']) ? 'selected' : '';
                                echo "<option value='" . $dept['department_name'] . "' $isSelected>" . $dept['department_name'] . "</option>";
                            }
                            ?>
                        </select>
                    </td>
                    <td>Sub Department:</td>
                    <td>
                        <select class="form-select" aria-label="Small select example" id="sub_department"
                            name="sub_department" required>
                            <option value="">Select Sub Department</option>
                            <?php
                            $selectedDepartment = $patientData['department'];
                            $subDepartment = $patientData['sub_department'];
                            $subDepartmentsSql = "SELECT sub_department FROM patients WHERE department = :department AND sub_department IS NOT NULL GROUP BY sub_department";
                            $subDepartmentsStmt = $pdo->prepare($subDepartmentsSql);
                            $subDepartmentsStmt->bindParam(':department', $selectedDepartment);
                            $subDepartmentsStmt->execute();
                            $subDepartments = $subDepartmentsStmt->fetchAll(PDO::FETCH_COLUMN);

                            foreach ($subDepartments as $subDept) {
                                $isSelected = ($subDept === $subDepartment) ? 'selected' : '';
                                echo "<option value='$subDept' $isSelected>$subDept</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <!-- Add more form fields for other patient details here -->
                <tr>
                    <td>Name:</td>
                    <td><input type="text" class="form-control" name="name" value="<?php echo $patientData['name']; ?>"
                            required></td>
                    <td>Age:</td>
                    <td><input type="number" class="form-control" name="age" value="<?php echo $patientData['age']; ?>"
                            required></td>
                </tr>
                <tr>
                    <td>Gender:</td>
                    <td>
                        <select class="form-select" aria-label="Small select example" id="gender" name="gender"
                            required>
                            <option value="">Select gender</option>
                            <option value="Male" <?php if ($patientData['gender'] === 'Male')
                                echo 'selected'; ?>>Male
                            </option>
                            <option value="Female" <?php if ($patientData['gender'] === 'Female')
                                echo 'selected'; ?>>
                                Female</option>
                            <option value="Other" <?php if ($patientData['gender'] === 'Other')
                                echo 'selected'; ?>>Other
                            </option>
                        </select>
                    <td>Contact No.:</td>
                    <td><input type="tel" class="form-control" name="contact" pattern="[0-9]{10}"
                            title="Mobile number should be 10 digits and only contain digits"
                            value="<?php echo $patientData['contact']; ?>" required></td>
                    </td>
                </tr>

                <tr>
                    <td>Aadhar No.:</td>
                    <td><input type="text" class="form-control" name="aadhar_no"
                            value="<?php echo $patientData['aadhar_no']; ?>" required></td>
                    <td>Registration Number:</td>
                    <td><input type="number" id="registration_number" name="registration_number" class="form-control"
                            value="<?php echo $patientData['registration_number']; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Date:</td>
                    <td><input type="date" name="date" id="date" value="<?php echo $patientData['date']; ?>" required
                            disabled></td>
                    <td>Time:</td>
                    <td><input type="time" name="time" id="time" value="<?php echo $patientData['time']; ?>" required
                            disabled></td>
                </tr>
                <tr>
                    <td colspan="5" align="center">
                        <center><input type="submit" value="UPDATE" class="btn btn-success btn-lg">
                            <a href="display.html" class="btn btn-primary btn-lg">Cancel</a>
                        </center>
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</body>

</html>