<?php
session_start();

// Include your database connection initialization
require_once('db_connection.php');

$currentUsername = '';

// Check if the user is logged in and retrieve the current username from the session
if (isset($_SESSION['user_id'])) {
    $userID = $_SESSION['user_id'];

    // Retrieve the current username from the database
    $query = "SELECT username FROM users WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$userID]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $currentUsername = $user['username'];
    }
}

$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = $_POST['new_username'];

    try {
        // Check if the new username is available
        $query = "SELECT COUNT(*) as count FROM users WHERE username = ? AND id != ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$newUsername, $userID]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result['count'] === 0) {
            // Update the username in the database
            $query = "UPDATE users SET username = ? WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$newUsername, $userID]);
    
            // Update the current username for display
            $currentUsername = $newUsername;
    
            $successMessage = "Username changed successfully.";
        } else {
            $errorMessage = "Username is already taken.";
        }
    } catch (PDOException $e) {
        $errorMessage = "Error changing username: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Include your head elements here -->
    <link rel="stylesheet" href="../css/register.css">

    <style>
        /* Add custom styles here */
        .content-box {
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .content-box:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        /* Custom styles for changing navigation bar item text color */
        .navbar-nav .nav-link {
            color: black; /* Change the color to black */
        }

    </style>
    <!-- Include your head elements here -->
</head>
<body>
    <!-- Your navigation bar content -->
    <nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">

      <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">

      <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
        <BR>PATIENT MEDICAL RECORD
      </h3>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </nav>
  <nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
      <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
        <ul class="navbar-nav">
        <li class="nav-item "> <!-- Add 'active' class here -->
        <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
            <b>Dashboard</b>
        </a>
        </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
             <b>Registration</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
              <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
              <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
              <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
              <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a></li>

            </ul>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <b>Profile</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="change_username.php"><b>Change username</b></a></li>
              <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
              <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
            </ul>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <b>Master</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
              <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
              <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
              <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
              <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6 content-box">
                <?php if (!empty($successMessage)) : ?>
                    <div class="alert alert-success"><?php echo $successMessage; ?></div>
                <?php endif; ?>
                <?php if (!empty($errorMessage)) : ?>
                    <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                <?php endif; ?>

                <h2>Change Username</h2>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="current_username">Current Username:</label>
                        <input type="text" class="form-control" id="current_username" value="<?php echo htmlspecialchars($currentUsername); ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label for="new_username">New Username:</label>
                        <input type="text" class="form-control" name="new_username" id="new_username" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="#" class="btn btn-danger">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
