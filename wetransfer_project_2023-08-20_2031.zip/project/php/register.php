<?php
require_once('user_info.php'); // Include the user_info.php file
authenticate(['admin','operator']);
// Include the database connection file
require_once('db_connection.php');

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST["name"];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        $contact = $_POST["contact"];
        $department = $_POST["department_name"];
        $sub_department = $_POST["sub_department"];
        $aadhar_no = $_POST["aadhar_no"];
        $registration_number = $_POST["registration_number"];
        $date = $_POST["date"];
        $time = $_POST["time"];

        $stmt = $pdo->prepare("INSERT INTO patients (name, age, gender, contact, department, sub_department, aadhar_no, registration_number, date, time) 
                                VALUES (:name, :age, :gender, :contact, :department, :sub_department, :aadhar_no, :registration_number, :date, :time)");

        // Bind parameters to the prepared statement
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":age", $age);
        $stmt->bindParam(":gender", $gender);
        $stmt->bindParam(":contact", $contact);
        $stmt->bindParam(":department", $department);
        $stmt->bindParam(":sub_department", $sub_department);
        $stmt->bindParam(":aadhar_no", $aadhar_no);
        $stmt->bindParam(":registration_number", $registration_number);
        $stmt->bindParam(":date", $date);
        $stmt->bindParam(":time", $time);

        // Execute the prepared statement
        $stmt->execute();

        // Return the registration number as a response
        echo $registration_number;
    }
} catch (PDOException $e) {
    http_response_code(500); // Set HTTP response code to indicate server error
    echo "Error: Connection failed.";
}

// Close the database connection
$conn = null;
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../css/register.css">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">
      <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">
      <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
        <BR>PATIENT MEDICAL RECORD
      </h3>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </nav>
  <nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
      <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
              <b>Dashboard</b>
            </a>
          </li>
          <?php if ($userRole === 'admin' || $userRole === 'operator'): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <b>Registration</b>
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
                <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
                <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
                <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
                <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <b>Profile</b>
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#"><b>Change username</b></a></li>
                <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
                <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
              </ul>
            </li>
          <?php endif; ?>
          <?php if ($userRole === 'admin'): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <b>Master</b>
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
                <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
                <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
                <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
                <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a>
                </li>
              </ul>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>


  <div class="container-fluid">
    <div id="successMessage" class="alert alert-success alert-dismissible" style="display: none;"></div>
    <form method="post" action="" id="registrationForm">

      <table align="center" class="table table-primary table-bordered table-bordered">
        <h2 align='center' class=" display-5 text-uppercase font-monospace">New Patient Registration</h2>
        <tr>
          <td>Department:</td>
          <td>
            <select class="form-select" aria-label="Small select example" id="department" name="department_name"
              required>
              <option value="">Select Department</option>
              <?php
              include 'db_connection.php';
              $sql = "SELECT department_name FROM departments WHERE enabled = 1"; // Fetch only enabled departments
              
              try {
                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                  echo "<option value='" . $row['department_name'] . "'>" . $row['department_name'] . "</option>";
                }
              } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
              }
              ?>
            </select>
          </td>

          <td>Sub Department:</td>
          <td>
            <select class="form-select" aria-label="Small select example" id="sub_department_name"
              name="sub_department" required>
              <option value="">Select Sub Department</option>
            </select>
          </td>

        </tr>

        <tr>
          <td>Name:</td>
          <td><input type="text" class="form-control" name="name" required></td>
          <td>Age:</td>
          <td><input type="number" class="form-control" name="age" required></td>
        </tr>
        <tr>
          <td>Gender:</td>
          <td>
            <select class="form-select" aria-label="Small select example" id="gender" name="gender" required>
              <option value="">Select gender</option>
              <option value="Male" required>Male</option>
              <option value="Female" required>Female</option>
              <option value="other" required>Other</option>
            </select>
          <td>Contact No.:</td>
          <td><input type="tel" class="form-control" name="contact" pattern="[0-9]{10}"
              title="Mobile number should be 10 digits and only contain digits" required></td>
          </td>
        </tr>

        <tr>
          <td>Aadhar No.:</td>
          <td><input type="text" class="form-control" name="aadhar_no" required></td>
          <td>Registration Number:</td>
          <td><input type="number" id="registration_number" name="registration_number" class="form-control" value="1"
              readonly></td>
        </tr>
        <tr>
          <td>Date:</td>
          <td><input type="date" name="date" id="date" required></td>
          <td>Time:</td>
          <td><input type="time" name="time" id="time" required></td>
        </tr>
        <tr>
          <td colspan="5" align="center">
            <center><input type="submit" value="SUBMIT" class="btn btn-success btn-lg">
              <input type="reset" name="res" value="RESET" class="btn btn-primary btn-lg" onclick="resetFormFields()">
            </center>
          </td>
        </tr>
      </table>
    </form>


    <table align="center" class="table table-striped table-bordered shadow-lg">
      <tr>
        <td colspan="5" align="center">
          <h2 align='center' class="display-6 font-monospace text-uppercase">Summary</h2>
        </td>
      </tr>
      <tr>
        <td>CT Scan:</td>
        <td><span id="ctScanCount">0</span></td>
      </tr>
      <tr>
        <td>MRI:</td>
        <td><span id="mriCount">0</span></td>
      </tr>
      <tr>
        <td>Ultrasound:</td>
        <td><span id="ultrasoundCount">0</span></td>
      </tr>
      <tr>
        <td>Total Appointments of Today:</td>
        <td><span id="totalRegistrations">0</span></td>
      </tr>
    </table>
  </div>
  </div>
  <script src="../bootstrap/jquery-3.7.0.min.js"></script>
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../bootstrap/js/popper.min.js"></script>
  <script src="../javascript/show_department.js"></script>
  <script src="../javascript/registration.js"></script>

</body>

</html>