<?php
require_once('user_info.php');
require_once('db_connection.php'); // Include your database connection code using PDO

// Check if the user is authenticated and has the 'admin' role
authenticate('admin');
$userRole = $_SESSION['user_role'];
$errorMessage = "";

// Handle enabling or disabling user when the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['userId'];

    try {
        // Toggle user status in the database
        $query = "UPDATE users SET enabled = NOT enabled WHERE id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$userId]);
    } catch (PDOException $e) {
        // Handle database error
        $errorMessage = "Error updating user status: " . $e->getMessage();
    }
}

// Retrieve user data from the database
$query = "SELECT * FROM users";
$stmt = $pdo->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enable/Disable Users</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/login.css">

 <style>
        .container {
            margin-top: 50px;
        }

        .table {
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
        }

        .btn-enable:hover {
            background-color: #28a745; /* Green color on hover */
            border-color: black;
        }

        .btn-disable:hover {
            background-color: #dc3545; /* Red color on hover */
            border-color: black;
        }

        .table-hover tbody tr:hover {
            background-color: #f8f9fa; /* Light gray background on row hover */
        }
    </style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
    <div class="container-fluid">
        <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">
        <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
            <BR>PATIENT MEDICAL RECORD
        </h3>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>
<nav class="navbar navbar-expand-lg"
    style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
    <div class="container">
      <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
        <ul class="navbar-nav">
        <li class="nav-item "> <!-- Add 'active' class here -->
        <a class="nav-link" href="admin.php" role="button" aria-expanded="false">
            <b>Dashboard</b>
        </a>
        </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
             <b>Registration</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="register.php"><b>New Registration</b></a></li>
              <li><a class="dropdown-item" href="edit_page.php"><b>Edit</b></a></li>
              <li><a class="dropdown-item" href="#"><b>Duplicate card</b></a></li>
              <li><a class="dropdown-item" href="../html/brief_summary.html"><b>Brief summary</b></a></li>
              <li><a class="dropdown-item" href="../html/detail_summary.html"><b>Detailed summary</b></a></li>

            </ul>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <b>Profile</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="change_username.php"><b>Change username</b></a></li>
              <li><a class="dropdown-item" href="#"><b>Change password</b></a></li>
              <li><a class="dropdown-item" href="../php/logout.php"><b>Logout</b></a></li>
            </ul>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <b>Master</b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="new_user.php"><b>New user</b></a></li>
              <li><a class="dropdown-item" href="add_department.php"><b>Add department</b></a></li>
              <li><a class="dropdown-item" href="add_sub_department.php"><b>Add sub-department</b></a></li>
              <li><a class="dropdown-item" href="enable_disable_user.php"><b>Enable/ disable user</b></a></li>
              <li><a class="dropdown-item" href="enable_disable_department.php"><b>Enable/ disable department</b></a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
    <div class="container mt-5">
        <?php if ($errorMessage) : ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        <table class="table table-success table-striped table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user) : ?>
                    <tr>
                        <td><?php echo $user['name']; ?></td>
                        <td><?php echo $user['username']; ?></td>
                        <td><?php echo $user['role']; ?></td>
                        <td><?php echo ($user['enabled'] ? 'Enabled' : 'Disabled'); ?></td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="userId" value="<?php echo $user['id']; ?>">
                                <button type="submit" class="btn <?php echo ($user['enabled'] ? 'btn-enable' : 'btn-disable'); ?>">
                                    <?php echo ($user['enabled'] ? 'Disable' : 'Enable'); ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>

