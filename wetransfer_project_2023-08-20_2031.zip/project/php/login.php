
<?php
session_start();

// Set the session timeout to 30 minutes (1800 seconds)
ini_set('session.gc_maxlifetime', 30);


// Include your database connection initialization
require_once('db_connection.php');

$loginError = false;
$loginErrorMessage = ''; // Initialize the combined error message

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, role, password, salt, enabled FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();

    if ($user && $user['enabled'] === 1 && password_verify($password . $user['salt'], $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];

        // Redirect based on the user's role
        switch ($user['role']) {
            case 'admin':
                header("Location: admin.php");
                exit();
            case 'pathologist':
                header("Location: pathologist.php");
                exit();
            case 'operator':
                header("Location: operator.php");
                exit();
            default:
                // Handle other roles or scenarios
                header("Location: unknown_role.php");
                exit();
        }
    } else {
        $loginError = true;
        if (!$user || $user['enabled'] === 0) {
            $loginErrorMessage = 'User is disabled'; // Set the error message
        } else {
            $loginErrorMessage = 'Invalid username or password'; // Set the error message
        }
    }
}
$currentUsername = isset($_SESSION['username']) ? $_SESSION['username'] : '';
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>

<body>
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom">
        <div class="container-fluid">
            <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 100px;">
            <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO<br>PATIENT
                MEDICAL RECORD</h3>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
    <div class="justify-content-center center container-fluid">
        <h1>Login</h1>
        <form method="post" action="">
            <?php if ($loginErrorMessage) { ?>
                <p class="error-message">
                    <?php echo $loginErrorMessage; ?>
                </p>
            <?php } ?>
            <div class="txt_field">
                <input type="text" name="username" required>
                <span></span>
                <label><b>Username</b></label>
            </div>
            <div class="txt_field">
                <input type="password" name="password" required>
                <span></span>
                <label><b>Password</b></label>
            </div>
            <div class="pass">Forgot Password?</div>
            <input type="submit" value="Login">
        </form>
    </div>
    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</body>

</html>