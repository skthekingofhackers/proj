<?php
// Include the database connection file
require_once('db_connection.php');

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST["name"];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        $contact = $_POST["contact"];
        $department = $_POST["department_name"];
        $sub_department = $_POST["sub_department"];
        $aadhar_no = $_POST["aadhar_no"];
        $registration_number = $_POST["registration_number"];
        $date = $_POST["date"];
        $time = $_POST["time"];

        $stmt = $pdo->prepare("INSERT INTO patients (name, age, gender, contact, department, sub_department, aadhar_no, registration_number, date, time) 
                                VALUES (:name, :age, :gender, :contact, :department, :sub_department, :aadhar_no, :registration_number, :date, :time)");

        // Bind parameters to the prepared statement
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":age", $age);
        $stmt->bindParam(":gender", $gender);
        $stmt->bindParam(":contact", $contact);
        $stmt->bindParam(":department", $department);
        $stmt->bindParam(":sub_department", $sub_department);
        $stmt->bindParam(":aadhar_no", $aadhar_no);
        $stmt->bindParam(":registration_number", $registration_number);
        $stmt->bindParam(":date", $date);
        $stmt->bindParam(":time", $time);

        // Execute the prepared statement
        $stmt->execute();

        // Return the registration number as a response
        echo $registration_number;
    }
} catch (PDOException $e) {
    http_response_code(500); // Set HTTP response code to indicate server error
    echo "Error: Connection failed.";
}

// Close the database connection
$conn = null;
?>
