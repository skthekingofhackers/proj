document.addEventListener("DOMContentLoaded", function () {
    var fromDateInput = document.getElementById("fromDate");
    var toDateInput = document.getElementById("toDate");
    var submitBtn = document.getElementById("submitBtn");
    var chartCanvas = document.getElementById("chartCanvas");
    var chartInstance = null;

    submitBtn.addEventListener("click", function () {
        var fromDate = fromDateInput.value;
        var toDate = toDateInput.value;
        fetchDataAndGenerateGraph(fromDate, toDate);
    });

    function fetchDataAndGenerateGraph(fromDate, toDate) {
        $.ajax({
            url: 'fetch_graph_data.php',
            method: 'POST',
            data: {
                from_date: fromDate,
                to_date: toDate
            },
            success: function(data) {
                if (chartInstance) {
                    chartInstance.destroy(); // Destroy the previous chart instance
                }
                generateChart(data);
            },
            error: function() {
                console.error('Error fetching graph data');
            }
        });
    }

    function generateChart(data) {
        var subDepartmentLabels = [];
        var ctScanData = [];
        var mriData = [];
        var ultrasoundData = [];
        var colors = [];

        data.forEach(function(item) {
            subDepartmentLabels.push(item.sub_department);
            ctScanData.push(item.ct_scan_total);
            mriData.push(item.mri_total);
            ultrasoundData.push(item.ultrasound_total);
            colors.push(getRandomColor());
        });

        var ctx = chartCanvas.getContext('2d');
        chartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: subDepartmentLabels,
                datasets: [
                    {
                        data: ctScanData,
                        label: 'CT Scan',
                        backgroundColor: colors[0],
                        borderColor: colors[0],
                        borderWidth: 1
                    },
                    {
                        data: mriData,
                        label: 'MRI',
                        backgroundColor: colors[1],
                        borderColor: colors[1],
                        borderWidth: 1
                    },
                    {
                        data: ultrasoundData,
                        label: 'Ultrasound',
                        backgroundColor: colors[2],
                        borderColor: colors[2],
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    x: {
                        stacked: true,
                        title: {
                            display: true,
                            text: 'Sub Departments'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'No. of Patients'
                        }
                    }
                }
            }
        });
    }

    function getRandomColor() {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }
});
