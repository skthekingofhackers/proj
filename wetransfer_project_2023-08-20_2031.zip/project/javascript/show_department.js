$(document).ready(function () {
  // Listen for department selection change
  $("#department").change(function () {
      var selectedDepartment = $(this).val();
      var subDepartmentSelect = $("#sub_department_name");
      subDepartmentSelect.empty(); // Clear previous options
      subDepartmentSelect.append($('<option value="">Select Sub Department</option>'));

      // Fetch and populate sub-department options based on the selected department
      $.ajax({
          url: "../php/get_sub_departments.php", // Replace with the actual server-side script
          method: "GET",
          data: { department: selectedDepartment },
          success: function (data) {
              var subDepartments = JSON.parse(data);

              // Populate sub-department options
              for (var i = 0; i < subDepartments.length; i++) {
                  subDepartmentSelect.append($('<option></option>').val(subDepartments[i]).html(subDepartments[i]));
              }
          }
      });
  });
});