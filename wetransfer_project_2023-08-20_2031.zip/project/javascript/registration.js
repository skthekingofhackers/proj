function showSuccessMessage(registrationNumber) {
    const successMessageDiv = document.getElementById('successMessage');
    
    if (registrationNumber.startsWith("Error:")) {
        successMessageDiv.innerHTML = "<span style='color: red;'>" + registrationNumber + "</span>";
    } else {
        successMessageDiv.innerHTML = "Registration successful! Your registration number is: " + registrationNumber;
    }
    
    successMessageDiv.style.display = 'block';
}


// Function to hide the success message pop-up
function hideSuccessMessage() {
    const successMessageDiv = document.getElementById('successMessage');
    successMessageDiv.innerText = ''; // Clear the inner text of the success message
    successMessageDiv.style.display = 'none';
}

// Function to validate name field (Only characters a to z and spaces)
function validateName() {
    const nameInput = document.querySelector('input[name="name"]');
    const nameValue = nameInput.value;
    const isValid = /^[a-zA-Z\s]+$/.test(nameValue); // Updated regex to allow spaces
    if (!isValid) {
        alert('Name can only contain alphabetic characters (a to z, A to Z) and spaces.');
        nameInput.value = '';
        nameInput.focus();
    }
}

// Function to validate age field (Only integers)
function validateAge() {
    const ageInput = document.querySelector('input[name="age"]');
    const ageValue = parseInt(ageInput.value);
    if (isNaN(ageValue) || ageValue < 1 || ageValue > 150) {
        alert('Age must be a valid integer between 1 and 150.');
        ageInput.value = '';
        ageInput.focus();
    }
}
// Function to enable sub_department selection when department is selected
function enableSubDepartmentSelection() {
    const departmentSelect = document.getElementById('department');
    const subDepartmentSelect = document.getElementById('sub_department_name'); // Correct the ID here

    if (departmentSelect.value === 'Imaging') { // Modify this condition accordingly
        subDepartmentSelect.disabled = false;
    } else {
        subDepartmentSelect.value = '';
        subDepartmentSelect.disabled = true;
    }
}


// Function to set current live time and today's date
function setCurrentDateTime() {
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');

    // Update the date and time fields every second
    setInterval(() => {
        const now = new Date();
        const currentDate = formatDate(now); // Get the current date in the format "YYYY-MM-DD"
        const currentTime = getCurrentTime(now);

        dateInput.value = currentDate;
        timeInput.value = currentTime;
    }, 1000); // Update every 1000 milliseconds (1 second)
}

// Function to format the date in "YYYY-MM-DD" format
function formatDate(date) {
    const year = date.getFullYear().toString();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Function to get the current live time in "hh:mm" format
function getCurrentTime(now) {
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}


// Function to fetch and update the dynamic appointment number
function updateRegistrationNumber() {
    $.ajax({
        type: "GET",
        url: "../php/get_latest_registration_number.php", // Change the URL accordingly
        success: function (data) {
            // Parse the fetched registration number
            const latestRegistrationNumber = parseInt(data);

            // If the fetched number is NaN or less than 1, set the registration number to 1
            const incrementedNumber = isNaN(latestRegistrationNumber) || latestRegistrationNumber < 1 ? 1 : latestRegistrationNumber + 1;

            // Display the updated registration number
            document.getElementById('registration_number').value = incrementedNumber;
        },
        error: function (xhr, status, error) {
            // Handle error if fetching the registration number fails
            console.log("Error fetching registration number: " + error);
        }
    });
}
// Function to reset form fields (except appointment number, date, and time)
function resetFormFields() {
    const form = document.getElementById('registrationForm');
    const registrationNumberInput = document.getElementById('registration_number');
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');

    const currentRegistrationNumber = registrationNumberInput.value;
    const currentDate = dateInput.value;
    const currentTime = timeInput.value;

    form.reset();

    // Restore the initial values of appointment number, date, and time fields
    registrationNumberInput.value = currentRegistrationNumber;
    dateInput.value = currentDate;
    timeInput.value = currentTime;

    // Hide the success message after resetting the form
    hideSuccessMessage();
}

// Attach event listeners to form fields
document.addEventListener('DOMContentLoaded', function () {
    const nameInput = document.querySelector('input[name="name"]');
    const ageInput = document.querySelector('input[name="age"]');
    const departmentSelect = document.getElementById('department');

    // Event listeners for constraints on name and age fields
    nameInput.addEventListener('blur', validateName);
    ageInput.addEventListener('blur', validateAge);

    // Event listener to enable sub_department selection when department is selected
    departmentSelect.addEventListener('change', enableSubDepartmentSelection);


    // Set current live time and today's date on page load
    setCurrentDateTime();

    // Event listener for form submission
    const submitButton = document.querySelector('input[type="submit"]');
    submitButton.addEventListener('click', function (event) {
        event.preventDefault(); // Prevent default form submission
        submitForm();
    });

    // Event listener for form reset
    const resetButton = document.querySelector('input[type="reset"]');
    resetButton.addEventListener('click', function (event) {
        event.preventDefault(); // Prevent default form reset behavior
        resetFormFields();
    });

    // Call the function to fetch and update the appointment number on page load
    updateRegistrationNumber();
});
