
    function updateCounts() {
        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    const data = JSON.parse(xhr.responseText);
                    
                    // Check if the data contains valid counts
                    if (typeof data.ctScanCount !== 'undefined' &&
                        typeof data.mriCount !== 'undefined' &&
                        typeof data.ultrasoundCount !== 'undefined') {

                        document.getElementById('ctScanCount').innerText = data.ctScanCount;
                        document.getElementById('mriCount').innerText = data.mriCount;
                        document.getElementById('ultrasoundCount').innerText = data.ultrasoundCount;

                        const totalAppointments = data.ctScanCount + data.mriCount + data.ultrasoundCount;
                        document.getElementById('totalRegistrations').innerText = totalAppointments;
                    } else {
                        console.error('Invalid data received.');
                    }
                } else {
                    console.error('Failed to fetch patient counts. Status:', xhr.status);
                }
            }
        };
        xhr.open('GET', '../php/count_patients.php', true);
        xhr.send();
    }

    updateCounts();
    setInterval(updateCounts, 10000);

