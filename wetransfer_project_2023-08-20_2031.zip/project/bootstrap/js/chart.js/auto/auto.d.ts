import {Chart} from '../dist/types.js';

export * from '../dist/types.js';
export default Chart;
