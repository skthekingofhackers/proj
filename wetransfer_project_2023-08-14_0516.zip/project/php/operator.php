<?php
require_once('auth.php');
authenticate('operator');

// Rest of your operator page code
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INMAS</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/register.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-custom" style="background-color: #80b1d3;">
        <div class="container-fluid">

            <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 110px;">

            <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO
                <BR>PATIENT MEDICAL RECORD
            </h3>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
    <nav class="navbar navbar-expand-lg" style="background: linear-gradient(to right, rgb(113, 113, 255), rgb(13, 102, 235));">
        <div class="container">
            <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../html/register.html">New Register</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../html/display.html">Patients</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Imaging
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">MRI</a></li>
                            <li><a class="dropdown-item" href="#">CT Scan</a></li>
                            <li><a class="dropdown-item" href="#">Ultrasound</a></li>
                            <li><a class="dropdown-item" href="#">X-Ray</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Medical Record</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Appointment</a>
                    </li>
                </ul>
            </div>
            <ul class="navbar-nav ml-1">
                <li class="nav-item">
                    <a href="logout.php" class="nav-link btn btn-danger">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <p align="center">WELCOME ...OPERTAOR NAME....</p>
    <script src="../bootstrap/js/jquery-3.7.0.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../bootstrap/js/popper.min.js"></script>
<script src="../bootstrap/js/jquery.slim.min.js"></script>

</body>

</html>