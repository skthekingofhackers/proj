<!DOCTYPE html>
<html>

<head></head>

<body>
    <?php

    $servername = "localhost";
    $username = "admin";
    $password = "admin";
    $dbname = "imaging_db";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $searchInput = isset($_GET['searchInput']) ? $_GET['searchInput'] : '';
        $searchOption = isset($_GET['searchOption']) ? $_GET['searchOption'] : '';

        $sql = "SELECT registration_number, name, contact, date, sub_department FROM patients";

        if (!empty($searchInput) && !empty($searchOption)) {
            $sql .= " WHERE $searchOption LIKE :searchInput";
        }

        $stmt = $conn->prepare($sql);

        if (!empty($searchInput) && !empty($searchOption)) {
            $stmt->bindValue(':searchInput', "%$searchInput%", PDO::PARAM_STR);
        }

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($result) > 0) { // Display records only if there are results
            echo "<table align='center' class='table table-bordered table-striped'>";
            echo "<thead align='center'>";
            echo "<tr class='table-bordered table-warning'>";
            echo "<th>App. No.</th>";
            echo "<th>Name</th>";
            echo "<th>Contact No.</th>";
            echo "<th>Date of Reg.</th>";
            echo "<th>Sub Department</th>";
            echo "<th>Report</th>";
            echo "<th>Modify</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody align='center' id='tableBody'>";

            foreach ($result as $row) {
                echo "<tr>";
                echo "<td>{$row['registration_number']}</td>";
                echo "<td>{$row['name']}</td>";
                echo "<td>{$row['contact']}</td>";
                echo "<td>{$row['date']}</td>";
                echo "<td>{$row['sub_department']}</td>";
                echo "<td><a class='text-primary' href='#'>Report</a></td>";
                echo "<td><a class='text-primary' href='../php/updateform.php?registration_number={$row['registration_number']}'>Edit</a></td>";
                echo "</tr>";
            }

            echo "</tbody>";
            echo "</table>";
        } else {
            echo "<p>No records found.</p>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null;
    ?>
</body>

</html>