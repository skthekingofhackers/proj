<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
  <body>
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom">
      <div class="container-fluid">
          <img src="../images/logo.png" alt="inmas" class="w-1 h-1" style="height: 100px;">
          <h3 class="navbar-heading ms-2" style="font-family: 'Times New Roman', Times, serif;">INMAS DRDO<br>PATIENT
              MEDICAL RECORD</h3>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
              aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>
      </div>
  </nav>
    <div class="justify-content-center center container-fluid">
      <h1>Login</h1>
      <form method="post" action="authenticate.php">
        <div class="txt_field">
          <input type="text" name="username" required>
          <span></span>
          <label>Username</label>
        </div>
        <div class="txt_field">
          <input type="password" name="password" required>
          <span></span>
          <label>Password</label>
        </div>
        <div class="pass">Forgot Password?</div>
        <input type="submit" value="Login">
      </form>
      <?php
      if (isset($loginError) && $loginError) {
          echo '<p class="error-message">Invalid username or password</p>';
      }
      ?>
    </div>
    <script src="../bootstrap/js/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
