<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient Details</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/register.css">
    <link rel="stylesheet" type="text/css" href="../css/login.css">
</head>

<body>
    <?php
    $servername = "localhost";
    $username = "admin";
    $password = "admin";
    $dbname = "imaging_db";
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $registrationNumber = $_GET['registration_number'];

        // Fetch the patient data from the database based on the registration number
        $sql = "SELECT * FROM patients WHERE registration_number = :registration_number";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':registration_number', $registrationNumber);
        $stmt->execute();
        $patientData = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    ?>

    <div class="container-fluid">
        <div id="successMessage" class="alert alert-success alert-dismissible" style="display: none;"></div>
        <form method="post" action="../php/update_patient.php" id="editForm">

            <table align="center" class="table table-striped table-bordered">
                <h2 align='center' class="display-5 text-uppercase font-monospace">Edit Patient Details</h2>
                <tr>
                    <td>Department:</td>
                    <td class="form-control">
                        <select class="form-select" aria-label="Small select example" id="department" name="department"
                            required>
                            <option value="">Select Department</option>
                            <option value="imaging" <?php if ($patientData['department'] === 'imaging') echo 'selected'; ?>>Imaging</option>
                        </select>
                    </td>
                    <td>Sub Department:</td>
                    <td>
                        <select class="form-select" aria-label="Small select example" id="sub_department"
                            name="sub_department" required>
                            <option value="">Select Sub Department</option>
                            <option value="CT scan" <?php if ($patientData['sub_department'] === 'CT scan') echo 'selected'; ?>>CT Scan</option>
                            <option value="Ultrasound" <?php if ($patientData['sub_department'] === 'Ultrasound') echo 'selected'; ?>>Ultrasound</option>
                            <option value="MRI" <?php if ($patientData['sub_department'] === 'MRI') echo 'selected'; ?>>MRI</option>
                        </select>
                    </td>
                </tr>
                
                <!-- Add more form fields for other patient details here -->
                <tr>
                    <td>Name:</td>
                    <td><input type="text" class="form-control" name="name" value="<?php echo $patientData['name']; ?>" required></td>
                    <td>Age:</td>
                    <td><input type="number" class="form-control" name="age" value="<?php echo $patientData['age']; ?>" required></td>
                </tr>
                <tr>
                    <td>Gender:</td>
                    <td>
                        <select class="form-select" aria-label="Small select example" id="gender" name="gender"
                            required>
                            <option value="">Select gender</option>
                            <option value="Male" <?php if ($patientData['gender'] === 'Male') echo 'selected'; ?>>Male</option>
                            <option value="Female" <?php if ($patientData['gender'] === 'Female') echo 'selected'; ?>>Female</option>
                            <option value="Other" <?php if ($patientData['gender'] === 'Other') echo 'selected'; ?>>Other</option>
                        </select>
                    <td>Contact No.:</td>
                    <td><input type="tel" class="form-control" name="contact" pattern="[0-9]{10}"
                            title="Mobile number should be 10 digits and only contain digits" value="<?php echo $patientData['contact']; ?>" required></td>
                    </td>
                </tr>

                <tr>
                    <td>Aadhar No.:</td>
                    <td><input type="text" class="form-control" name="aadhar_no" value="<?php echo $patientData['aadhar_no']; ?>" required></td>
                    <td>Registration Number:</td>
                    <td><input type="number" id="registration_number" name="registration_number" class="form-control"
                            value="<?php echo $patientData['registration_number']; ?>" readonly></td>
                </tr>
                <tr>
                    <td>Date:</td>
                    <td><input type="date" name="date" id="date" value="<?php echo $patientData['date']; ?>" required disabled></td>
                    <td>Time:</td>
                    <td><input type="time" name="time" id="time" value="<?php echo $patientData['time']; ?>" required disabled></td>
                </tr>
                <tr>
                    <td colspan="5" align="center">
                        <center><input type="submit" value="UPDATE" class="btn btn-success btn-lg">
                            <a href="display.html" class="btn btn-primary btn-lg">Cancel</a>
                        </center>
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <script src="../bootstrap/jquery-3.7.0.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
