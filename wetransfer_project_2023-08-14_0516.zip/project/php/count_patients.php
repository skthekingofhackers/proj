<?php
$servername = "localhost";
$username = "admin";
$password = "admin";
$dbname = "imaging_db";

date_default_timezone_set("Asia/Kolkata");

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $today = date("Y-m-d");

    $sql = "SELECT COUNT(*) AS ctScanCount FROM patients WHERE sub_department = 'CT Scan' AND DATE_FORMAT(date, '%Y-%m-%d') = :today";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':today', $today);
    $stmt->execute();
    $ctScanCount = $stmt->fetchColumn();

    $sql = "SELECT COUNT(*) AS mriCount FROM patients WHERE sub_department = 'MRI' AND DATE_FORMAT(date, '%Y-%m-%d') = :today";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':today', $today);
    $stmt->execute();
    $mriCount = $stmt->fetchColumn();

    $sql = "SELECT COUNT(*) AS ultrasoundCount FROM patients WHERE sub_department = 'Ultrasound' AND DATE_FORMAT(date, '%Y-%m-%d') = :today";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':today', $today);
    $stmt->execute();
    $ultrasoundCount = $stmt->fetchColumn();

    $conn = null;

    $data = array(
        'ctScanCount' => $ctScanCount,
        'mriCount' => $mriCount,
        'ultrasoundCount' => $ultrasoundCount
    );

    header('Content-Type: application/json');
    echo json_encode($data);
} catch (PDOException $e) {
    $response = array(
        'status' => 'error',
        'message' => $e->getMessage()
    );

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
