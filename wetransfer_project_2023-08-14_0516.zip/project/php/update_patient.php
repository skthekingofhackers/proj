<?php
$servername = "localhost";
$username = "admin";
$password = "admin";
$dbname = "imaging_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $department = $_POST['department'];
    $subDepartment = $_POST['sub_department'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $aadharNo = $_POST['aadhar_no'];
    $registrationNumber = $_POST['registration_number'];

    $sql = "UPDATE patients SET department = :department, sub_department = :sub_department,
            name = :name, age = :age, gender = :gender, contact = :contact, aadhar_no = :aadhar_no
            WHERE registration_number = :registration_number";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':department', $department);
    $stmt->bindParam(':sub_department', $subDepartment);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':age', $age);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':contact', $contact);
    $stmt->bindParam(':aadhar_no', $aadharNo);
    $stmt->bindParam(':registration_number', $registrationNumber);

    $stmt->execute();

    header("Location: ../html/display.html"); // Redirect back to the display page
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
