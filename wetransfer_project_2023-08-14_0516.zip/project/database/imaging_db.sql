-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 08, 2023 at 09:57 PM
-- Server version: 10.11.4-MariaDB-1
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imaging_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `appointment_number` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `department` varchar(50) NOT NULL,
  `sub_department` varchar(50) NOT NULL,
  `aadhar_no` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`appointment_number`, `name`, `age`, `gender`, `contact`, `department`, `sub_department`, `aadhar_no`, `date`, `time`) VALUES
(1, 'sunil kumar', 20, 'Male', '9654083988', 'imaging', 'CT scan', '498192301362', '2023-08-07', '21:03:00'),
(2, 'sunny', 22, 'Male', '9654083988', 'imaging', 'Ultrasound', '498192301363', '2023-08-07', '21:03:00'),
(3, 'sunny kumar', 22, 'Male', '9053647890', 'imaging', 'MRI', '498192301364', '2023-08-07', '21:03:00'),
(4, 'dqsnjk', 20, 'Male', '9654083988', 'imaging', 'Ultrasound', '498192300002', '2023-08-07', '21:41:00'),
(5, 'fsnaks', 20, 'Male', '9678583988', 'imaging', 'MRI', '498192300003', '2023-08-07', '21:49:00'),
(6, 'sunil', 23, 'Male', '9654083988', 'imaging', 'Ultrasound', '345766780876', '2023-08-07', '22:04:00'),
(7, 'sunil', 23, 'Male', '9654083988', 'imaging', 'Ultrasound', '345766780876', '2023-08-07', '22:06:00'),
(8, 'sunil kumar', 77, 'Male', '8847438292', 'imaging', 'CT scan', '293849494949', '2023-08-07', '22:14:00'),
(9, 'askdfna', 36, 'Male', '8976566547', 'imaging', 'Ultrasound', '467567490234', '2023-08-07', '22:21:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` enum('admin','pathologist','operator') NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `username`, `password`) VALUES
(1, 'admin', 'admin', '$2y$10$jvPcB9r7zeocgb.dzi1tsuD2/reKzqzOjqsVohPZEnTmnDziT/NNm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`appointment_number`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
