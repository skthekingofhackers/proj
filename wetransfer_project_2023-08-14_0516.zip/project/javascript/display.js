
$(document).ready(function () {
    $('form').submit(function (event) {
        event.preventDefault(); // Prevent the form from submitting normally

        var searchInput = $('#searchInput').val();
        var searchOption = $('#searchOption').val();

        // Send AJAX request to fetch search results
        $.ajax({
            type: 'GET',
            url: '../php/display.php', // Change this to the actual path of your PHP script
            data: {
                searchInput: searchInput,
                searchOption: searchOption
            },
            success: function (data) {
                // Replace the table body with the new search results
                $('#tableBody').html(data);
            },
            error: function () {
                alert('An error occurred while fetching data.');
            }
        });
    });
});

